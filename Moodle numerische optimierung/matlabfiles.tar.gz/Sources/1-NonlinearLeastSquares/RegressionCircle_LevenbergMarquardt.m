clear; close all;
%----prescribe the data ---------------------------------------- 
N=100;                          % no of points
dr = 0.1;                      % max deviation from radius 2
                                % severelv impacts convergence
rad_L=(2*dr).*randn(N,1)+2-dr;  % radius with random distortions
zx_L=3;                         % 'exact' center coordinate
zy_L=2;                         % 
x_L=zx_L*ones(N,1) + cos(linspace(0,2*pi,N)').*rad_L;
y_L=zy_L*ones(N,1) + sin(linspace(0,2*pi,N)').*rad_L;
%---------------------------------------------------------------

x=x_L;
y=y_L;
m=length(x);

%--- provide F and Jacobian as functions -----------------------
F=@(p) sqrt((x-p(1)).^2+(y-p(2)).^2)-p(3);
DF=@(p) [(p(1)-x)./sqrt((x-p(1)).^2+(y-p(2)).^2), ...
         (p(2)-y)./sqrt((x-p(1)).^2+(y-p(2)).^2), ...
         -ones(m,1)];
%---------------------------------------------------------------
%-- initial value - might severely influence convergence
p0=[1;1;1];

maxit=100; 
tol=1e-10;

[xLM,itsLM]=levenberg_marquardt(F,DF,p0,1,0.3,0.9,maxit,tol,1);

fprintf('Levenberg-Marquardt: center = (%12.8f,%12.8f), radius=%12.8f\n',...
        xLM(1),xLM(2),xLM(3));

figure(1)
hold on
plot(x,y,'x','Linewidth',1,'MarkerEdgeColor','k');
fplot(@(t) xLM(3)*sin(t)+xLM(1), @(t) xLM(3)*cos(t)+xLM(2),'k','Linewidth',1);
hold off

figure(2);
semilogy(itsLM(:,3),'Linewidth',1.5);
grid on;

maxk=size(itsLM,1);
fileID = fopen('../../Data/RegCircleLMData.txt','w');
for (k=1:maxk)
    fprintf(fileID,'%i & %12.8f & %12.8f & %12.8f & %12.8f & %12.8f\\\\ \\hline\n',...
        k,itsLM(k,1),itsLM(k,2),itsLM(k,3),itsLM(k,4),itsLM(k,5));
end
fclose(fileID);

