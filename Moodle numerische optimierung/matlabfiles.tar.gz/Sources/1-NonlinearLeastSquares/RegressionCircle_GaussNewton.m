clear; close all;
%----prescribe the data ---------------------------------------- 
N=100;                          % no of points
dr = 0.025;                      % max deviation from radius 2
                                % severelv impacts convergence
rad_L=(2*dr).*randn(N,1)+2-dr;  % radius with random distortions
zx_L=3;                         % 'exact' center coordinate
zy_L=2;                         % 
x_L=zx_L*ones(N,1) + cos(linspace(0,2*pi,N)').*rad_L;
y_L=zy_L*ones(N,1) + sin(linspace(0,2*pi,N)').*rad_L;
%---------------------------------------------------------------

x=x_L;
y=y_L;
m=length(x);

%--- provide F and Jacobian as functions -----------------------
F=@(p) sqrt((x-p(1)).^2+(y-p(2)).^2)-p(3);
DF=@(p) [(p(1)-x)./sqrt((x-p(1)).^2+(y-p(2)).^2), ...
         (p(2)-y)./sqrt((x-p(1)).^2+(y-p(2)).^2), ...
         -ones(m,1)];
%---------------------------------------------------------------

%-- initial value - might severely influence convergence
p0=[1;1;1];

maxit=100; 
tol=1e-10;

[xGN,itsGN]=gauss_newton(F,DF,p0,maxit,tol,1);

fprintf('Gauss-Newton: center = (%12.8f,%12.8f), radius=%12.8f\n',...
        xGN(1),xGN(2),xGN(3));

figure(1)
hold on
plot(x,y,'x','Linewidth',1,'MarkerEdgeColor','k');
fplot(@(t) xGN(3)*sin(t)+xGN(1), @(t) xGN(3)*cos(t)+xGN(2),'k','Linewidth',1);
hold off

figure(2);
semilogy(itsGN(:,3),'Linewidth',1.5);
grid on;

maxk=size(itsGN,1);
fileID = fopen('../../Data/RegCircleGNData.txt','w');
for (k=1:maxk)
    fprintf(fileID,'%i & %12.8f & %12.8f & %12.8f & %12.8f\\\\ \\hline\n',...
        k,itsGN(k,1),itsGN(k,2),itsGN(k,3),itsGN(k,4));
end
fclose(fileID);

