clear all; close all;
%----prescribe the data ---------------------------------------- 
N=100;                          % no of points
dr = 0.05;                      % max deviation from radius 2
rad_L=(2*dr).*randn(N,1)+2-dr;  % radius with random distortions
zx_L=3;                         % 'exact' center coordinate
zy_L=2;                         % with random distorions
x_L=zx_L*ones(N,1) + cos(linspace(0,2*pi,N)').*rad_L;
y_L=zy_L*ones(N,1) + sin(linspace(0,2*pi,N)').*rad_L;
%---------------------------------------------------------------

x=x_L;
y=y_L;
m=length(x);

F=@(p) sqrt((x-p(1)).^2+(y-p(2)).^2)-p(3);
DF=@(p) [(p(1)-x)./sqrt((x-p(1)).^2+(y-p(2)).^2), ...
         (p(2)-y)./sqrt((x-p(1)).^2+(y-p(2)).^2), ...
         -ones(m,1)];
        
p0=[1;1;1];
%p0=[2;1;1];

maxit=100; 
tol=1e-10;

%=========== Gauss-Newton ========================
[xGN,itsGN]=gauss_newton(F,DF,p0,maxit,tol,1);

fprintf('Gauß-Newton: center = (%12.8f,%12.8f), radius=%12.8f\n',...
    xGN(1),xGN(2),xGN(3));

%---------------------------------------------
figure(1)
hold on
plot(x,y,'x','Linewidth',1,'MarkerEdgeColor','k');
fplot(@(t) xGN(3)*sin(t)+xGN(1), @(t) xGN(3)*cos(t)+xGN(2),'k','Linewidth',1);
hold off
exportgraphics(gca,'../../Data/Regression_GN.png','Resolution',300) 
%---------------------------------------------
figure(2);
semilogy(itsGN);
grid on;
exportgraphics(gca,'../../Data/Regression_GN_its.png','Resolution',300) 

%---------------------------------------------
maxk=size(itsGN,1);
fileID = fopen('../../Data/GNData.txt','w');
for (k=1:maxk)
    fprintf(fileID,'%i & %12.8f\\\\ \n',k,itsGN(k));
end
fclose(fileID);

%=========== Levenberg-Marquardt ========================
q=levenberg_marquardt(F,DF,p0,1,0.3,0.9,maxit,tol,1);

fprintf('Levenberg-Marquardt: center = (%12.8f,%12.8f), radius=%12.8f\n',...
    q(1),q(2),q(3));

figure(3)
hold on
plot(x,y,'x','Linewidth',1,'MarkerEdgeColor','k');
fplot(@(t) q(3)*sin(t)+q(1), @(t) q(3)*cos(t)+q(2),'k','Linewidth',1);
hold off
exportgraphics(gca,'../../Data/Regression_LM.png','Resolution',300) 
