%-- This file is adapted from W. Dahmen, A. Reusken
%-- Numerik fuer Ingenieure und Naturwissenschaftler, 3. Aufl.
%-- Springer, 2022
%-- https://www.igpm.rwth-aachen.de/DahmenReusken/demodownload
clear; close all;

%-- data
ti=[0.1 0.3 0.7 1.2 1.6 2.2 2.7 3.1 3.5 3.9]';
bi=[0.558 0.569 0.176 -0.207 -0.133 0.132 0.055 -0.090 -0.069 0.027]';

x=ti; y=bi;
p0=[1, 2, 2, 1]';

%--- provide F and Jacobian as functions -----------------------
F=@(p) p(1).*exp(-p(2).*x).*sin(p(3).*x+p(4))-y;
DF=@(p) [exp(-p(2).*x).*sin(p(3).*x+p(4)),...
         -p(1).*x.*exp(-p(2).*x).*sin(p(3).*x+p(4)),...
         p(1).*x.*exp(-p(2).*x).*cos(p(3).*x+p(4)),...
         p(1).*exp(-p(2).*x).*cos(p(3).*x+p(4))];
%---------------------------------------------------------------

maxit=100; 
tol=1e-6;

[xLM,itsLM]=levenberg_marquardt(F,DF,p0,1,0.3,0.9,maxit,tol,1);

fprintf('Levenberg-Marquardt: u= %12.8f, delta=%12.8f, omega=%12.8f,phi=%12.8f\n',...
        xLM(1),xLM(2),xLM(3),xLM(4));

figure(1)
t=linspace(0,4);
hold on
plot(t,xLM(1)*exp(-xLM(2).*t).*sin(xLM(3).*t+xLM(4)),'linewidth',2)
plot(ti,bi,'o','MarkerSize',8,'MarkerFaceColor','red');
hold off
xlabel('$t$','Interpreter','latex');  
ylabel('$F(x^k,t)$','Interpreter','latex')
legend('fitted model','data')

figure(2);
semilogy(itsLM(:,3),'Linewidth',1.5);
grid on;

maxk=size(itsLM,1);
fileID = fopen('../../Data/OscillationLMData.txt','w');
for (k=1:maxk)
    fprintf(fileID,'%i & %12.8f & %12.8f & %12.8f & %12.8f & %12.8f \\\\ \\hline\n',...
        k,itsLM(k,1),itsLM(k,2),itsLM(k,3),itsLM(k,4),itsLM(k,5));
end
fclose(fileID);
