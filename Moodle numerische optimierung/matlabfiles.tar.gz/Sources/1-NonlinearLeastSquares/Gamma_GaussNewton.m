close all; clear;
%-- requires Matlab Statistics and Machine Learning Toolbox


%-- data is produced by distorting an exact Gamma-distribution
lambda_ex = 1.5;
p_ex = 2;

%-- step sizes for Finite Difference approximation
dp=0.1;
dl=0.1;

%-- data
N_data=20;   %- no of data points
sigma=0.015; %- distortions are in [-sigma, sigma]
t_data=linspace(0.05,9.95,N_data);
dy=(2*sigma).*randn(N_data,1)-sigma;
y_data = (gampdf(t_data,p_ex,lambda_ex)'+dy)';
x=t_data; y=y_data;

%-- parameters for Gauss-Newton iteraiotn
p0=[1;1];  %- initial value
maxit=100; %- max number of iterations
tol=1e-10; %- tolerance

%--- provide F and Jacobian as functions -----------------------
F=@(p) [gampdf(x,p(1),p(2))-y]';
DF=@(p)[(gampdf(x,p(1)+dp,p(2))-gampdf(x,p(1),p(2)))'./dp,...
        (gampdf(x,p(1),p(2)+dl)-gampdf(x,p(1),p(2)))'./dl];
%---------------------------------------------------------------

[xGN,itsGN]=gauss_newton(F,DF,p0,maxit,tol,1);
fprintf('Gauss-Newton: p = %12.8f, lambda=%12.8f\n',xGN(1),xGN(2));

%---------------------------------------------------------------
%- compare with 'exact' Gamma distribution
N=100;
t=linspace(0,10,N);
gamma_t = gampdf(t,p_ex,lambda_ex);

figure(1)
plot(t,gampdf(t,xGN(1),xGN(2)),'linewidth',2);
hold on
plot(t,gamma_t,'c--','linewidth',2);
plot(t_data,y_data,'o','MarkerSize',6,'MarkerFaceColor','red');
hold off
legend('fitted curve','original','data');

%- convergence histoty
figure(2);
semilogy(itsGN(:,3),'Linewidth',1.5);
grid on;

maxk=size(itsGN,1);
fileID = fopen('../../Data/GammaGNData.txt','w');
for (k=1:maxk)
    fprintf(fileID,['%i & %12.8f & %12.8f & %12.8f & %12.8f...' ...
        '\\\\ \\hline\n'], k,itsGN(k,1),itsGN(k,2),...
        itsGN(k,3),itsGN(k,4));
end
fclose(fileID);
