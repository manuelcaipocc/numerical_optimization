%-- This file is adapted from W. Dahmen, A. Reusken
%-- Numerik fuer Ingenieure und Naturwissenschaftler, 3. Aufl.
%-- Springer, 2022
%-- https://www.igpm.rwth-aachen.de/DahmenReusken/demodownload

%-- data
ti=[0.1 0.3 0.7 1.2 1.6 2.2 2.7 3.1 3.5 3.9]';
bi=[0.558 0.569 0.176 -0.207 -0.133 0.132 0.055 -0.090 -0.069 0.027]';

x=ti; y=bi;
p0=[1, 2, 2, 1]';

%--- provide F and Jacobian as functions -----------------------
F=@(p) p(1).*exp(-p(2).*x).*sin(p(3).*x+p(4))-y;
DF=@(p) [exp(-p(2).*x).*sin(p(3).*x+p(4)),...
         -p(1).*x.*exp(-p(2).*x).*sin(p(3).*x+p(4)),...
         p(1).*x.*exp(-p(2).*x).*cos(p(3).*x+p(4)),...
         p(1).*exp(-p(2).*x).*cos(p(3).*x+p(4))];
%---------------------------------------------------------------

maxit=100; 
tol=1e-6;

[xGN,itsGN]=gauss_newton(F,DF,p0,maxit,tol,1);

fprintf('Gauss-Newton: u= %12.8f, delta=%12.8f, omega=%12.8f,phi=%12.8f\n',...
        xGN(1),xGN(2),xGN(3),xGN(4));

figure(1)
t=linspace(0,4);
hold on
plot(t,xGN(1)*exp(-xGN(2).*t).*sin(xGN(3).*t+xGN(4)),'linewidth',2)
plot(ti,bi,'o','MarkerSize',8,'MarkerFaceColor','red');
hold off
xlabel('$t$','Interpreter','latex');  
ylabel('$F(x^k,t)$','Interpreter','latex')
legend('fitted model','data')

figure(2);
semilogy(itsGN(:,3),'Linewidth',1.5);
grid on;

maxk=size(itsGN,1);
fileID = fopen('../../Data/OscillationGNData.txt','w');
for (k=1:maxk)
    fprintf(fileID,'%i & %12.8f & %12.8f & %12.8f & %12.8f\\\\ \\hline\n',...
        k,itsGN(k,1),itsGN(k,2),itsGN(k,3),itsGN(k,4));
end
fclose(fileID);
