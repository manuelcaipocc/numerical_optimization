function [x, iter] = levenberg_marquardt(F,DF,x0,mu0,beta0,beta1,maxit,tol,flag)
    if ~exist('flag','var')
      flag = 0;
    end
    iter=zeros(maxit,5);
    n=length(x0);
    k=0;
    mu=mu0; 
    x=x0;
    errorold = norm(DF(x0)'*F(x0));
    s=-(DF(x0)'*DF(x0)+mu^2*eye(n))\(DF(x0)'*F(x0));
    while norm(s)>tol && k<maxit
        [s,mu] = korrektur(F,DF,x,mu,beta0,beta1);
        x=x+s;
        k=k+1;
        fx=F(x);
        errornew=norm(DF(x)'*fx);
        iter(k,1)=norm(fx);
        iter(k,2)=norm(s);
        iter(k,3)=norm(errornew);
        iter(k,4)=errornew/errorold;
        iter(k,5)=mu;
        errorold=errornew;
        if (flag~=0)
            fprintf('%i\t %12.8f\t %12.8f\t %12.8f\t %12.8f\t %12.8f\n',...
                k,iter(k,1),iter(k,2),iter(k,3),iter(k,4),iter(k,5));
        end
   end
   iter=iter(1:k,:);
 end

function [s,mu] = korrektur(F,DF,x,mu,beta0,beta1)
    n=length(x);
    s=-(DF(x)'*DF(x)+mu^2*eye(n))\(DF(x)'*F(x));
    eps_mu=(F(x)'*F(x)-F(x+s)'*F(x+s))/...
        (F(x)'*F(x)-(F(x)+DF(x)*s)'*(F(x)+DF(x)*s));
    if eps_mu <= beta0 
        [s,mu]=korrektur(F,DF,x,2*mu,beta0,beta1);
    elseif eps_mu >= beta1 
        mu=mu/2;
    end           
end