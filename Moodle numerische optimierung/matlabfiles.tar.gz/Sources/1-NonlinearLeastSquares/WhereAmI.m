
function WhereAmI
clear all
close all
%-----------------------------------------------------------------
% data: cols 1:2 position on map
%       col  3   sea level height
%       cols 4:5 position on picture
dat = [ 3700, 4125, 2627.6,  -0.0280,  0.0340;
        2200, 3175, 2720.0,   0.0025,  0.0265;
        2350, 6000, 2136.0,   0.0325,  0.0355;
        2175, 5885, 2072.0,   0.0370,  0.0305;
        1850, 5950, 2276.5,   0.0505, 0.0390];

%-- these are the pixel data of the image of the map
MapData = [ 215, 498;
            123, 550;
            135, 382;
            108, 390;
            78, 400];

%-- we computed a weighted 2-norm
weight = 10000;

%-----------------------------------------------------------------
%-- Gauss-Newton method for solving the nonlinear least squares
%-- problem ||F(x)||_2 = min!
%-- initial data
L     = [ 6000; 9000; 600];
d     = [0; -0.2; 0];
theta = 0;
x = [d; L; theta];
k=0;

x_all = x; %-- store all iterations
fileID = fopen('../../Data/WhereAmIGNData.txt','w+');

[Fx, JFx] = F(x, dat);
errorold = norm(JFx'*Fx);

while 1
  k=k+1;
  % determine F(x) and JF(x)
  [Fx, JFx] = F(x, dat);
  error = norm(JFx'*Fx);
  
  % linear least squares probl -> update dx
  dx = JFx\Fx;
  x = x - dx;
  
  x_all = [x_all, x];
  % weighted norm
  dxnorm = max([weight*norm(dx(1:3)), norm(dx(4:6)), weight*abs(dx(7))]);
  fxnorm = norm(Fx);
  [Fx, JFx] = F(x, dat);
  errornew = norm(JFx'*Fx);
  rho = errornew/errorold; 
  errorold=errornew;
  
  fprintf('||F(x)|| = %14.8f,  ||dx|| = %12.8f, err = %12.8f\n',...
          fxnorm,dxnorm,error);
  fprintf(fileID,'%i & %12.8f & %12.8f & %12.8f & %12.8f\\\\ \\hline\n',...
        k,fxnorm,dxnorm,error,rho);
    
  % stop if update is small
  if dxnorm < 0.1
    break;
  end
end
fclose(fileID);

%-----------------------------------------------------------------
  
%-- display the results  
%-- show the iterations for the lenses on the map
L  = x_all(4:5,:);  
LP = TransformMapImage(dat(1:3,1:2)', MapData(1:3,:)', L);

mf=figure(1);
Image=imread([pwd,'/MountainMap.jpg']);
image(Image);

hold on 
orig = scatter(MapData(:,1),MapData(:,2),'filled','blue','pentagram');
orig.SizeData=150;
plot(LP(1,:)',LP(2,:)','k+-','linewidth',2,'markersize',8);
plot(LP(1,end)',LP(2,end)','ro','linewidth',2,'markersize',8);
for i=1:5
    plot([LP(1,end),MapData(i,1)],[LP(2,end),MapData(i,2)],...
        'b-','linewidth',1);
end
axis off

set(mf, 'PaperOrientation', 'landscape');
set(mf, 'PaperUnits', 'inches');
set(mf, 'PaperSize', [11 8.5]);
set(mf, 'PaperPositionMode', 'manual');
set(mf, 'PaperPosition', [0 0 11 8.5]);
set(gca, 'Position', [0 0 1 1]); % image fills the entire figure
print('../../Data/ThereAmI.pdf', '-dpdf', '-r0'); 

%-----------------------------------------------------------------
% determine F(x) and jacobian JF(x)     
function [Fx, JFx] = F(x, dat)
    % dimensions
    m  = 3*size(dat,1);
    n  = 7;
    Fx = zeros(m, 1);
    JFx = zeros(m, n);
    
    % F: first 3 rows
    for i = 1:size(dat,1)
      i0 = 3*i-2;
      [Fx(i0:i0+2),JFx(i0:i0+2,:)] = Fi(x(1:3),x(4:6),x(7),...
                                        dat(i,1:3)',dat(i,4:5)');
    end
%-----------------------------------------------------------------

%-----------------------------------------------------------------
% F(x) and JF(x) for given data 
function [Fvalue, JFvalue] = Fi(d, L, theta, Q, M)
    %-- determine ONB (d,e,f) with d orth. to picture (note the sign!)
    dnorm=norm(d);
    %--
    e = [d(2); -d(1); 0];
    enorm = norm(e);
    e = e/enorm;
    %-- e=h*d
    f = [-d(1)*d(3); -d(2)*d(3); d(1)^2+d(2)^2];
    fnorm = norm(f);
    f = f/fnorm;

    %-- position of the current summit after rotation  
    S = [cos(theta), sin(theta); -sin(theta), cos(theta)]*M;
    %-- vector w from 3d picture position to center of gravity
    %-- in (d,e,f)-coordinates
    %-- the first 1 turns outward of the picture
    w = [d, e, f]*[1; S];
    
    %-- w should be collinear to Q-L, this is F(x)
    Fvalue = cross(w, Q-L);

    %-- now JF_i 
    JFvalue = zeros(3, 7);

    %-- derivative w.r.t. L
    JFvalue(:,4:6) = -[cross(w,[1;0;0]), cross(w,[0;1;0]), ...
                       cross(w,[0;0;1])];

    %-- derivative w.r.t. theta
    du_dtheta = [-sin(theta), cos(theta); -cos(theta), -sin(theta)]*M;
    dw_dtheta = [e, f]*[du_dtheta];
    JFvalue(:,7) = cross(dw_dtheta, Q-L);
 
    %-- derivative w.r.t. d = (a;b;c) = (d_1;d_2;d_3)
    dh_da = [0; -1; 0]/enorm - d(1)*e/enorm^2;
    dh_db = [1;  0; 0]/enorm - d(2)*e/enorm^2;
    dh_dc = [0;0;0];
    dg_da = [-d(3); 0; 2*d(1)]/fnorm - f*d(1)*(1/(enorm^2) ...
                                        + 1/(dnorm^2));
    dg_db = [0; -d(3); 2*d(2)]/fnorm - f*d(2)*(1/(enorm^2) ...
                                        + 1/(dnorm^2));
    dg_dc = [-d(1); -d(2); 0]/fnorm - f*d(3)*(1/(dnorm^2));
    dw_da = [[1;0;0], dh_da, dg_da]*[1; S];
    dw_db = [[0;1;0], dh_db, dg_db]*[1; S];
    dw_dc = [[0;0;1], dh_dc, dg_dc]*[1; S];
    
    JFvalue(:,1) = cross(dw_da, Q-L);
    JFvalue(:,2) = cross(dw_db, Q-L);
    JFvalue(:,3) = cross(dw_dc, Q-L);
%-----------------------------------------------------------------

%-----------------------------------------------------------------
% transformation of points from the map to the image
function ImageData = TransformMapImage(MapBase, ImageBase, MapData)
    % base vectors on image
    B = ImageBase(:,2:3) - [ImageBase(:,1), ImageBase(:,1)];
    % base vectors on map
    C = MapBase(:,2:3) - [MapBase(:,1), MapBase(:,1)];
    % matrix of the change of basis
    A = B/C;
    % transform center of gravity
    b = (1/3)*ImageBase*ones(3, 1) - A*(1/3)*MapBase*ones(3, 1);
    % transform x -> Ax+b
    ImageData = A*MapData + b*ones(1, size(MapData, 2));
%-----------------------------------------------------------------
