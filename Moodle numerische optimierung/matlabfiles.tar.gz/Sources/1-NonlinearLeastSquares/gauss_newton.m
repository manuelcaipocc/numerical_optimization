function [x, iter] = gauss_newton(F,DF,x0,maxit,tol,flag)

    if ~exist('flag','var')
      flag = 0;
    end
    iter=zeros(maxit,4);
    k=0;
    x=x0; 
    errorold = norm(DF(x0)'*F(x0));
    s=-(DF(x0)'*DF(x0))\(DF(x0)'*F(x0));
    while norm(s)>tol && k<maxit
        k=k+1;
        x=x+s; 
        fx=F(x);
        s=-(DF(x)'*DF(x))\(DF(x)'*fx);
        errornew=norm(DF(x)'*fx);
        iter(k,1)=norm(fx);
        iter(k,2)=norm(s);
        iter(k,3)=norm(errornew);
        iter(k,4)=errornew/errorold;
        errorold=errornew;
        if (flag~=0)
            fprintf('%i\t %12.8f\t %12.8f\t %12.8f\t %12.8f\n',...
                k,iter(k,1),iter(k,2),iter(k,3),iter(k,4));
        end
    end
    iter=iter(1:k,:);
end