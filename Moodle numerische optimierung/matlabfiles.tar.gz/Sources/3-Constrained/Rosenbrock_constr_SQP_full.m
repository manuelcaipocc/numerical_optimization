Rosenbrock = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;
fun  = @(x) Rosenbrock(x(1),x(2));
x0 = [-1.9,2];
opts = optimoptions('fmincon','PlotFcn',@lsqplot,'Algorithm','sqp');
[x,fval,eflag,output] = fmincon(fun,x0,[],[],[],[],[],[],@nlcon,opts)
exportgraphics(gca,'../../Data/Rosenbrock_constr_SQP_full.png','Resolution',300) 


function [c,ceq] = nlcon(x)
    ceq = [];
    c = x(1)^2 + x(2)^2 - 1.5;
end

function stop = lsqplot(x,~,state)
    persistent hist
    stop = false;

    switch state
        case 'init'
            hist = x;
            fun = @(x,y)log(1 + (10*(y - x.^2).^2 + (1 - x).^2)); % log for cleaner contours
            fcontour(fun,[-2 2 -1 3],'LevelList',[1:5])
            hold on
            axis equal
            %plot(0,0,"ko",'MarkerSize',156)
            th = 0:pi/50:2*pi;
            xunit = sqrt(1.5) * cos(th);
            yunit = sqrt(1.5) * sin(th);
            h = plot(xunit, yunit,'k-','LineWidth',1.5);
            xlim([-2,2])
            ylim([-1,3])
        case 'iter'
            hist = [hist;x];
            plot(x(1),x(2),"kx") % Plot iterative points
            plot(hist(:,1),hist(:,2),'--k')
        case 'done'
            text(hist(1,1),hist(1,2),' Start point')
            text(hist(end,1),hist(end,2),' Solution')
            title("SQP Method on Nonlinearly Constrained Rosenbrock's Function")
            hold off
    end
end