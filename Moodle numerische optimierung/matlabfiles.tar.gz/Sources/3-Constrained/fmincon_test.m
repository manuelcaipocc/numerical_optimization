%-- test fmincon
func = @(x,y) (x-2)^2+(y-2)^2;
f = @(x) func(x(1),x(2));


%-- constraint function
g1 = @(x) x(1).^2-x(2).^2;
g2 = @(x) x(1)+x(2)-2;


nonlcon = @constrains;
x0 = [0 0];
A = [];     % No other constraints
b = [];
Aeq = [];
beq = [];
lb = [];
ub = [];

options = optimoptions('fmincon','Display','iter',...
    'ConstraintTolerance',1e-7,...
    'OptimalityTolerance',1e-7);
[x,fval,exitflag,output] = fmincon(f,x0,A,b,Aeq,beq,lb,ub,nonlcon,options);

fprintf('fmincon\n');
fprintf('Optimal point x^*: (%12.8f, %12.8f)\n ',x(1),x(2));
fprintf('f(x^*) = (%12.8f)\n ',fval);
fprintf('g_1(x^*) = (%12.8f)\n ',g1(x));
fprintf('g_2(x^*) = (%12.8f)\n ',g2(x));
fprintf('no. of its: %o\n',output.iterations);

fprintf('-------------------------------------------------------\n')


function [c,ceq] = constrains(x)
    c(1) = x(1).^2-x(2).^2;
    c(2) = x(1)+x(2)-2;
    ceq = [];
end