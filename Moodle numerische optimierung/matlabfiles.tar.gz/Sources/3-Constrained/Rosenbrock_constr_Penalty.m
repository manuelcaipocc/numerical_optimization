close all; clear
tau=1.0;


%-- Rosenbrock function with derivatives
Rosenbrock = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;
f  = @(x) Rosenbrock(x(1),x(2));
Jf = @(x) [-400*(x(2)-x(1)^2)*x(1)-2*(1-x(1));
            200*(x(2)-x(1)^2)];
Hf = @(x)  [1200*x(1)^2-400*x(2)+2, -400*x(1);...
                         -400*x(1), 200];  

x = [1.0 -1.0]';
% x = [0.90802896   0.82420137]'; % solution with tau=10, x=(1,-1)
% x = [0.90739443   0.82304722]'; % solution with tau=50, x=(1,-1)
r2=1.5;
%-- constraint function
h  = @(x) x(1).^2+x(2).^2-r2;
Jh = @(x) [2*x(1); 2*x(2)];
Hh = @(x) [2, 0; 0, 2];


L  = @(x) f(x) + tau/2*h(x)'*h(x);
JL = @(x) Jf(x) + tau*Jh(x)*h(x);
HL = @(x) Hf(x) + tau*Hh(x)*h(x) + tau*Jh(x)*Jh(x)';

% Armijo stepsize rule parameters
sigma = .1;
beta = .5;
obj=L(x);
g=HL(x)\JL(x);
k=0;        % k = # iterations
nf=1;		% nf = # function eval.	
allx = x;


fileID = fopen('../../Data/Rosenbrock_constr_Penalty.txt','w+');
    
% Begin method
  while (norm(g) > 1e-6) && (k<1000) 
    d = -g;                   % steepest descent directionfunx
    a = 1;
    newobj = L(x + a*d);
    nf = nf+1; its=0;
    while ((newobj-obj)/a > sigma*g'*d) && (its<500)
      a = a*beta;
      newobj = L(x + a*d);
      nf = nf+1; its = its+1;
    end
    fprintf('%5.0f %5.0f %12.5e \n',k,nf,obj); 
    fprintf(fileID,'%5.0f & %5.0f & %12.5e \\\\ \\hline\n',k,nf,obj); 
    x = x + a*d;
    allx=[allx x];
    obj=newobj;
    g=HL(x)\JL(x);
    k = k + 1;
  end
    
fclose(fileID);
  
fprintf('Optimal point x^*: (%12.8f, %12.8f)\n',x(1),x(2));
fprintf('L(x^*) = %12.8f, h(x^*)= %12.8f, ||JL(x^*)||=%12.8f, tau=%4.2f\n',...
    obj,h(x),norm(JL(x)),tau);
fprintf('#f = %i, ',nf);
fprintf('no. of its: %i',k);
if (k==1000) fprintf('***'); end
fprintf('\n\n');

fprintf('%4.2f\t & %12.8f\t & %12.8f\t & %12.8f\t & %i \\\\ \\hline \n\n',...
    tau, h(x), norm(JL(x)), obj, k);

xp = linspace(-1.5,1.5); yp = linspace(-1.5,3);
[xx,yy] = meshgrid(xp,yp); ff = Rosenbrock(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(xp,yp,ff,levels,LW,1.2), colorbar
axis([-1.5 1.5 -1.5 3]), axis square, hold on
plot(allx(1,:),allx(2,:),'k+-','LineWidth',1.0);
th = 0:pi/50:2*pi;
xunit = sqrt(1.5) * cos(th);
yunit = sqrt(1.5) * sin(th);
plot(xunit, yunit,'r-','LineWidth',1.5);
hold off
exportgraphics(gca,'../../Data/Rosenbrock_constr_Penalty.png','Resolution',300) 



