close all; clear
rho    = 5;   %-- multiplication factor for tau
tau    = 1.0; %-- initial value for tau
lambda = 1.0; %-- initial Lagrange multiplier

x = [1 -1]'; %-- initial value for iteration
r2=1.5;           %-- square of radius for constraint

%-- Rosenbrock function with derivatives
Rosenbrock = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;
f  = @(x) Rosenbrock(x(1),x(2));
Jf = @(x) [-400*(x(2)-x(1)^2)*x(1)-2*(1-x(1));
            200*(x(2)-x(1)^2)];
Hf = @(x)  [1200*x(1)^2-400*x(2)+2, -400*x(1);...
                         -400*x(1), 200];  

%-- constraint function
h  = @(x) x(1).^2+x(2).^2-r2;
Jh = @(x) [2*x(1); 2*x(2)];
Hh = @(x) [2, 0; 0, 2];

%-- penalty function
L  = @(x,tau) f(x) + tau/2*h(x)'*h(x);
JL = @(x,tau) Jf(x) + tau*Jh(x)*h(x);
HL = @(x,tau) Hf(x) + tau*Hh(x)*h(x) + tau*Jh(x)*Jh(x)';

%-- Lagrange multipler function
G  = @(x,lambda, tau) L(x,tau)  + lambda'*h(x);
JG = @(x,lambda, tau) JL(x,tau) + lambda'*Jh(x);
HG = @(x,lambda, tau) HL(x,tau) + lambda'*Hh(x);

% Armijo stepsize rule parameters
sigma = .1;
beta = .5;

k=0;        % k = # iterations
nf=1;		% nf = # function eval.	
allx = x;
x_old= x;

fileID = fopen('../../Data/Rosenbrock_constr_Lagrange_full.txt','w+');
    
% Begin method
while (norm(h(x))>1e-6) || (abs(f(x_old)-f(x))>1e-6)
  x_old=x;
  g=HG(x,lambda,tau)\JG(x,lambda,tau);
  obj=G(x,lambda,tau);
  while (norm(g) > 1e-6) && (k<1000) 
    d = -g;                   % steepest descent direction
    a = 1;
    newobj = G(x + a*d,lambda,tau);
    nf = nf+1; its=0;
    while ((newobj-obj)/a > sigma*g'*d) && (its<500)
      a = a*beta;
      newobj = G(x + a*d,lambda,tau);
      nf = nf+1; its = its+1;
    end
    fprintf('%i %6.4f %5.0f %5.0f %12.5e %12.5e \n',...
                tau,lambda,k,nf,obj,norm(h(x))); 
    fprintf(fileID,'%i & %6.4f & %12.5e & %12.5e \\\\ \\hline\n',...
                    tau,lambda,f(x),norm(h(x))); 
    x = x + a*d;
    allx=[allx x];
    obj=newobj;
    g=HG(x,lambda,tau)\JG(x,lambda,tau);
    k = k + 1;
  end
  lambda = lambda + tau*h(x);
  tau    = rho*tau;
end

fclose(fileID);
  
fprintf('Optimal point x^*: (%12.8f, %12.8f)\n',x(1),x(2));
fprintf('f(x^*) = %12.8f, h(x^*)= %12.8f\n',...
        f(x),h(x));
fprintf('#f = %i, ',nf);
fprintf('no. of its: %i',k);
if (k==1000) fprintf('***'); end
fprintf('\n\n');


xp = linspace(-1.5,1.5); yp = linspace(-1.5,3);
[xx,yy] = meshgrid(xp,yp); ff = Rosenbrock(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(xp,yp,ff,levels,LW,1.2), colorbar
axis([-1.5 1.5 -1.5 3]), axis square, hold on
plot(allx(1,:),allx(2,:),'k+-','LineWidth',1.0);
th = 0:pi/50:2*pi;
xunit = sqrt(1.5) * cos(th);
yunit = sqrt(1.5) * sin(th);
plot(xunit, yunit,'r-','LineWidth',1.5);
hold off
exportgraphics(gca,'../../Data/Rosenbrock_constr_Lagrange_full.png','Resolution',300) 



