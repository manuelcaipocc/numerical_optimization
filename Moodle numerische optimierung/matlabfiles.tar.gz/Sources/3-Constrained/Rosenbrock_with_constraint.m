close all; clear

f = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;

r=sqrt(1.5);

x = linspace(-1.5,1.5); y = linspace(-1.5,3);
[xx,yy] = meshgrid(x,y); 
ff = f(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([-1.5 1.5 -1.5 3]), axis square, 
hold on
th = 0:pi/50:2*pi;
xunit = r * cos(th);
yunit = r * sin(th);
plot(xunit, yunit,'k-','LineWidth',1.5);
hold off
exportgraphics(gca,'../../Data/Rosenbrock_constrained.png','Resolution',300) 


figure(2), mesh(x,y,ff);



tau=10;
%-- constraint function
h  = @(x,y) x.^2+y.^2-r^2;

figure(3);
gg = f(xx,yy) + tau/2*h(xx,yy).^2;
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
contour(x,y,gg,levels,LW,1.2), colorbar
axis([-1.5 1.5 -1.5 3]), axis square, 
hold on
th = 0:pi/50:2*pi;
xunit = r * cos(th);
yunit = r * sin(th);
plot(xunit, yunit,'k-','LineWidth',1.5);
hold off
exportgraphics(gca,'../../Data/Rosenbrock_constrained_tau.png','Resolution',300) 
