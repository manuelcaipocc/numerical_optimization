%-- test fmincon

%-- Rosenbrock function with derivatives
Rosenbrock = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;
f  = @(x) Rosenbrock(x(1),x(2));
Jf = @(x) [-400*(x(2)-x(1)^2)*x(1)-2*(1-x(1));
            200*(x(2)-x(1)^2)];
Hf = @(x)  [1200*x(1)^2-400*x(2)+2, -400*x(1);...
                         -400*x(1), 200];  

%-- constraint function
h  = @(x) x(1).^2+x(2).^2-1.5;
Jh = @(x) [2*x(1); 2*x(2)];
Hh = @(x) [2, 0; 0, 2];

nonlcon = @circle;
x0 = [0 0];
A = [];     % No other constraints
b = [];
Aeq = [];
beq = [];
lb = [];
ub = [];

options = optimoptions('fmincon','Display','iter',...
    'ConstraintTolerance',1e-7,...
    'OptimalityTolerance',1e-7);
[x,fval,exitflag,output] = fmincon(f,x0,A,b,Aeq,beq,lb,ub,nonlcon,options);

fprintf('fmincon\n');
fprintf('Optimal point x^*: (%12.8f, %12.8f)\n ',x(1),x(2));
fprintf('f(x^*) = (%12.8f), ',fval);
fprintf('h(x^*) = (%12.8f), ',h(x));
fprintf('no. of its: %o\n',output.iterations);
fprintf('-------------------------------------------------------\n')

function [c,ceq] = circle(x)
    c(1) = x(1).^2+x(2).^2-1.5;
    ceq = [];
end