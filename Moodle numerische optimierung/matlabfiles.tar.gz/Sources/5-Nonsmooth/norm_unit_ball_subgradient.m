close all; clear

%- variable space dimension
d=10;
fprintf('Space dimension: d=%i\n', d);

% -- offset
b = 2*ones(d,1);
% -- initial point
x0 = [2:d+1]';  


% objective function f(x) = ||x||_2^2
f = @(x) norm(x-b)^2;
g = @(x) 2*(x-b);       % subgradient of f(x), i.e., g(x) = 2*x

% Define the projection onto the unit ball
% proj = @(x) min(1, 1/norm(x)) * x;
proj = @(x) x; %-- this is 'standard' subgradient method


% Define a step size rule (e.g., diminishing step size)
% step_size_rule = @(k) 1 / sqrt(k);
step_size_rule = @(k) 2 / (k+1);

% Maximum number of iterations
max_iters = 100;
tolerance = 1e-4;

% Run the Projected Subgradient Method
[x_opt, f_val, allx, k_max] = projected_subgradient_method(f, g, proj, x0, ...
    max_iters, step_size_rule,tolerance,1);

fprintf('Optimal solution: x = ['); 
for i=1:d-1
    fprintf('%.4f, ',x_opt(i));
end
fprintf('%.4f]\n',x_opt(d));
fprintf('Optimal function value: f(x) = %.4f\n', f_val);
fprintf('Iterations: %i\n', k_max);


% Plot the function value over iterations
x_exact=proj(b);
f_exact=f(x_exact);
max_i=min(k_max+1,max_iters+1);
step=1;
% Plot the function value over iterations
for i=1:d
    xx(i,:)=allx(i,1:step:max_i);
end

figure;
for i=1:size(xx,2)
    allf(i) = abs(f(xx(:,i))-f_exact);
end

semilogy(1:step:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('|f(x^{(k)})-f^*|');
grid on;
axis tight

exportgraphics(gca,'../../Data/Norm_Unit_Ball_Subgradient_History.png','Resolution',300) 



