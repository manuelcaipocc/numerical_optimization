%% Subgradient method function
function [x, f_val, allx,iter] = subgradient_method(f, subgrad_f, x0, ...
                                    max_iter, step_size_rule, tolerance,...
                                    outflag)
    
    % Initialization
    x = x0;
    allx=[x];
    d = size(x,1);
    
    for k = 1:max_iter
        subgrad = subgrad_f(x);
        g = subgrad/norm(subgrad);
        alpha = step_size_rule(k);

       % Check for convergence
        if (norm(subgrad) < tolerance) || (alpha < tolerance)
            break;
        end
        
        x = x - alpha * g;  % update
        
        allx=[allx,x];
        iter = k;
        f_val = f(x);

       if (outflag==1)
          % Display progress (optional)
          fprintf('Iteration %i: , x=[',k);
          for i=1:d-1
                fprintf('%.4f, ',x(i));
            end
          fprintf('%.4f], ',x(d));
          fprintf('f(x) = %.4f, ||Df(x)|| = %.4f, alpha = %.4f\n',...
                        f_val, norm(subgrad), alpha);
       end
    end
end