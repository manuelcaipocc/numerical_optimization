% Main function to execute the bundle method
function bundle_method_with_regularization_vector()
    % Define the objective functions
    f1 = @(x) (x - 2).^2;  % f1(x) = (x - 2)^2
    f2 = @(x) x.^3;        % f2(x) = x^3
    f = @(x) max(f1(x), f2(x)); % f(x) = max(f1, f2)

    % Initial point
    x0 = 3;  % Change initial point to test
    epsilon = 1e-6; % Stopping tolerance
    max_iter = 100; % Maximum iterations
    reg_param = 0.1; % Regularization parameter
    max_bundle_size = 5; % Maximum size of the bundle

    % Run the bundle method with regularization
    [x_opt, f_opt, num_iter] = bundle_method(f, @compute_subgradient, x0, epsilon, max_iter, reg_param, max_bundle_size);

    fprintf('Optimal point: %.4f\n', x_opt);
    fprintf('Optimal value of f(x): %.4f\n', f_opt);
    fprintf('Number of iterations: %d\n', num_iter);
end

function [x_opt, f_opt, k] = bundle_method(f, subgrad_func, x0, epsilon, max_iter, reg_param, max_bundle_size)
    x = x0;
    k = 0;
    bundle = [];
    bundle_values = [];
    bundle_subgrads = [];
    
    while k < max_iter
        k = k + 1;
        f_val = f(x);
        
        % Compute subgradients
        g_k = subgrad_func(x);
        
        % Add current point to the bundle
        bundle = [bundle; x]; % Store as a row vector
        bundle_values = [bundle_values; f_val];
        bundle_subgrads = [bundle_subgrads; g_k'];
        
        % Maintain bundle size
        if size(bundle, 1) > max_bundle_size
            [~, idx] = max(bundle_values); % Remove the point with the highest value
            bundle(idx, :) = [];
            bundle_values(idx) = [];
            bundle_subgrads(idx, :) = [];
        end
        
        % Solve the bundle problem using quadratic programming
        x_new = solve_bundle(bundle, bundle_values, bundle_subgrads, reg_param);
        
        % Check for convergence
        if norm(x_new - x) < epsilon
            break;
        end
        
        x = x_new;
    end
    
    x_opt = x;
    f_opt = f(x);
end

function x_new = solve_bundle(bundle, bundle_values, bundle_subgrads, reg_param)
    % Number of bundle points
    n = size(bundle, 1);
    
    % Define the QP problem to minimize: 0.5 * x' * H * x + f' * x
    H = reg_param * eye(n); % Regularization term
    f = (bundle_subgrads' * bundle) - bundle_values; % Linear term

    % Solve the QP problem
    options = optimoptions('quadprog', 'Display', 'off');
    x_new = quadprog(H, f, [], [], ones(1, n), 1, [], [], [], options); % Adding constraints

    % If quadprog fails, return the mean of the bundle points
    if isempty(x_new)
        x_new = mean(bundle);
    end
end

function g = compute_subgradient(x)
    % Compute subgradient for max(f1, f2)
    f1_val = (x - 2).^2;
    f2_val = x.^3;

    if f1_val >= f2_val
        g = 2 * (x - 2); % Subgradient of f1
    else
        g = 3 * x^2;     % Subgradient of f2
    end
end

% Call the main function
bundle_method_with_regularization_vector();
