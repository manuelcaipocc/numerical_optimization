close all; clear

mf=figure(1);
Image=imread([pwd,'/GermanCities.png']);
[rows, columns, numberOfColorChannels] = size(Image);
stretchedImage = imresize(Image, 3*[rows columns]);
imshow(stretchedImage);

% Hamburg, Berlin, Ulm, Bonn, Kassel, Passau, Rostock, Saarbrücken
data=[620, 1117, 618, 190, 540, 1122, 933, 173;
      385, 638, 1590, 1060, 928, 1551, 241, 1393];

hold on;
plot(data(1,:)',data(2,:)','bo','linewidth',2,...
    'markersize',8,'MarkerFaceColor','blue');
hold off;

m=size(data,2);
omega = ones(m,1);

x0=[0,0];


f = @(x) omega'*vecnorm([x(1)-data(1,:);x(2)-data(2,:)])';

options = optimoptions('fminunc','Algorithm','trust-region');
[x,fval,exitflag,options] = fminunc(f,x0)

figure(1)
hold on
plot(x(1),x(2),'ko','linewidth',2,...
    'markersize',14,'MarkerFaceColor','black');
for i=1:m
    plot([x(1) data(1,i)],[x(2), data(2,i)],'linewidth',1,...
        'Color','black');
end
hold off

exportgraphics(gca,'../../Data/Location2.png','Resolution',300) 
