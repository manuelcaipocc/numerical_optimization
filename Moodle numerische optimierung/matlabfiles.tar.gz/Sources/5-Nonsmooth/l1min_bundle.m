% Example usage of the bundle algorithm with realistic KKT solver
x0 = randn(5,1); % Initial guess
gamma = 0.5;
eta = 0.1;
epsilon = 1e-6;
max_iter = 100;

f = @(x) f_example(x);
Jf = @(x) subgradient_function(f, x);

% Call the bundle algorithm
[x_opt, f_opt, k] = bundle_algorithm(f,Jf,x0,gamma, eta, epsilon, max_iter);

fprintf('Optimal solution found after %d iterations.\n', k);
fprintf('x_opt = \n');
disp(x_opt);
fprintf('f_opt = %f\n', f_opt);


function f_val = f_example(x)
    % Example of a nonsmooth objective function: L1 norm
    f_val = sum(abs(x));
end


function s = subgradient_function(f, x)
    % Compute a subgradient at the point x
    % For smooth functions, this is just the gradient.
    % For nonsmooth functions, we approximate the subgradient.
    
    % Finite difference method to approximate subgradients
    epsilon = 1e-8;
    n = length(x);
    s = zeros(n, 1);
    for i = 1:n
        e_i = zeros(n, 1);
        e_i(i) = 1;
        s(i) = (f(x + epsilon * e_i) - f(x)) / epsilon;
    end
end
