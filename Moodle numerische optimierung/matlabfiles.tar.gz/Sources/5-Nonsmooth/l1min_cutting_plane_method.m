clear all; close


% Example usage: Minimize a nonsmooth convex function
% Define the function f(x) = ||x||_1 (L1 norm)
f = @(x) norm(x, 1);

% Define the subgradient of f(x)
subgrad_f = @(x) sign(x);

% Initial guess for x
d = 10;  %- space dimension
x0 = 3*ones(d,1);

% Parameters
tol = 1e-5;
max_iters = 200;

% Run the Cutting Plane Method
[x_sol, f_vals, k_max] = cutting_plane_method(f, subgrad_f, x0, tol, max_iters);

% Display results
fprintf('Optimal point x=[');
for i=1:d-1
  fprintf('%.4f, ',x_sol(i));
end
fprintf('%.4f]\n ',x_sol(d));
fprintf('Optimal value of f(x): %.4e\n', f_vals(end));
fprintf('Number of iterations: %d\n', k_max);


% Plot the function value over iterations
figure;
semilogy(1:k_max, f_vals, 'LineWidth', 2);
xlabel('Iteration');
ylabel('|f(x^{(k)})-f^*|');
grid on;
axis tight

exportgraphics(gca,'../../Data/l1min_CuttingPlane_History.png','Resolution',300) 
