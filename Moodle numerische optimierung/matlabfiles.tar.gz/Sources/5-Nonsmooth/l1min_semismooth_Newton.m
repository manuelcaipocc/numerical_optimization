% Example usage
% Problem setup
m = 50;   % Number of equations
n = 100;  % Number of unknowns

% Create a random underdetermined system
A = randn(m, n);
x_true = zeros(n, 1);
s = 10; % Sparsity level
x_true(randperm(n, s)) = randn(s, 1);
b = A * x_true;

% Initial guess for x
x0 = zeros(n, 1);

% Parameters
tol = 1e-6;
max_iters = 100;


% Define the function F(x) = A' * lambda(x) + sign(x) - where lambda(x) solves Ax = b
F = @(x) A' * (A * x - b) + sign(x);
    
% Define the Jacobian J(x)
J = @(x) A' * A + diag(1./max(abs(x), tol));
    
% Call the generic semismooth Newton method
[x_sol, iter, res] = semismooth_newton_method(F, J, x0, tol, max_iters);

% Display results
fprintf('Recovered nonzero elements of x: \n');
disp(find(abs(x_sol) > 1e-4)); % Use a threshold for non-zeros

% Plot original vs recovered signal
figure;
stem(1:n, x_true, 'bo', 'LineWidth', 2); hold on;
stem(1:n, x_sol, 'rx', 'LineWidth', 2);
xlabel('Index');
ylabel('Value');
legend('True x', 'Recovered x');
title('L1-Minimization: True vs Recovered Signal (Semismooth Newton)');
grid on;

