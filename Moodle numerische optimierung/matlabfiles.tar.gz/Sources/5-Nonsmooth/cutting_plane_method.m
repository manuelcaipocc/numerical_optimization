function [x, f_vals, iter] = cutting_plane_method(f, grad_f, x0, tol, max_iters)
    % Cutting plane method for convex optimization
    %
    % Inputs:
    % - f: Function handle for the objective function f(x)
    % - grad_f: Function handle for the gradient of f(x)
    % - x0: Initial guess for x
    % - tol: Convergence tolerance
    % - max_iters: Maximum number of iterations
    %
    % Outputs:
    % - x: Solution vector
    % - f_vals: History of the function values at each iteration
    % - iter: Number of iterations performed
    
    % Initialize variables
    x = x0;
    f_vals = zeros(max_iters, 1);
    cuts = {};  % List of cuts (linear constraints)
    
    % Parameters
    epsilon = 1e-6;  % Small constant for numerical stability
    
    for iter = 1:max_iters
        % Solve the relaxed problem with current cuts
        [x_new, f_new] = solve_relaxed_problem(f, grad_f, x, cuts, epsilon);
        
        % Store the function value
        f_vals(iter) = f_new;
        
        % Check convergence
        if norm(x_new - x) < tol && abs(f_new - f(x)) < tol
            x = x_new;
            break;
        end
        
        % Update the current solution
        x = x_new;
        
        % Generate and add new cut
        new_cut = generate_cut(x, grad_f(x), f(x));
        cuts = [cuts, {new_cut}];
    end
    
    % Truncate the f_vals array if convergence was reached early
    f_vals = f_vals(1:iter);
end

function [x_opt, f_opt] = solve_relaxed_problem(f, grad_f, x, cuts, epsilon)
    % Solve the relaxed problem with current cuts
    % The relaxed problem is min f(x) subject to all cuts
    % Define the objective function for the relaxed problem
    obj_fun = @(x_new) f(x_new);
    
    % Define constraints
    A = []; b = [];
    for i = 1:length(cuts)
        cut = cuts{i};
        A = [A; cut.A];
        b = [b; cut.b];
    end
    
    % Solve the linear problem with constraints
    options = optimoptions('fmincon', 'Display', 'off');
    x_opt = fmincon(obj_fun, x, A, b, [], [], [], [], [], options);
    f_opt = f(x_opt);
end

function cut = generate_cut(x, grad_f_x, f_x)
    % Generate a new cut (linear constraint)
    % The cut is defined as: grad_f_x' * (x - x0) <= f(x) - f(x0)
    cut.A = -grad_f_x';  % -grad_f_x to form the constraint
    cut.b = f_x - grad_f_x' * x;  % f(x) - grad_f_x' * x
end

