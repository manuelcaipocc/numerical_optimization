% Subgradient method for minimizing f(x) = |x|
close all; clear

%-- function handles for f and subgradient
f = @(x) abs(x);;
subgrad_f = @(x) diag(sign(x) + (x == 0));

%-- function handle for step size
step_size = @(k) step_size_rule(k);

% Parameters
max_iter  = 5000; % Maximum number of iterations
tolerance = 1e-3; % Tolerance for stopping criterion
x0 = [1.0];  % Starting point 

% Run the subgradient method
[x_opt, f_opt, allx,max_k] = subgradient_method(f, subgrad_f, x0, ...
                                    max_iter, step_size, tolerance,1);

% Output the final result
fprintf('Optimal point: x = %f\n', x_opt);
fprintf('Final function value: f(x) = %f\n', f(x_opt));
fprintf('Iterations: %i\n', max_k);

max_i=min(1000,max_k);
step=9;
% Plot the function value over iterations
xx=allx(1:step:max_i);
allf=f(xx);
figure;
semilogy(1:step:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('f(x)');
grid on;

exportgraphics(gca,'../../Data/Abs_Subgradient_History.png','Resolution',300) 


%% Stepsize rule
function alpha = step_size_rule(k)
    alpha = 1./(k+1);
end