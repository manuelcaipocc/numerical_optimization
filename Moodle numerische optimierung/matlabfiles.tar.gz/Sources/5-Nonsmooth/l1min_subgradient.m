clear all; close

% Example usage: Minimize a nonsmooth convex function
% Define the function f(x) = ||x||_1 (L1 norm)
f = @(x) norm(x, 1);

% Define the subgradient of f(x)
subgrad_f = @(x) sign(x);

% Initial guess for x
d = 10;  %- space dimension
x0 = 3*ones(d,1);

% Parameters
tol = 1e-3;
max_iters = 200;

% % Run the Bundle Method
% [x_sol, f_vals, iter] = bundle_method(f, subgrad_f, x0, tol, max_iters);

% Define a step size rule (e.g., diminishing step size)
step_size_rule = @(k) 2 / (k+1);


% Run the Projected Subgradient Method
[x_opt, f_val, allx, k_max] = subgradient_method(f, subgrad_f, x0, ...
    max_iters, step_size_rule, tol,1);


% Display results
fprintf('Optimal value of f(x): %.4e\n', f_val);
fprintf('Number of iterations: %d\n', k_max);


max_i=min(k_max+1,max_iters+1);
step=1;
% Plot the function value over iterations
for i=1:d
    xx(i,:)=allx(i,1:step:max_i);
end

figure;
f_exact=0;
for i=1:size(xx,2)
    allf(i) = abs(f(xx(:,i))-f_exact);
end

semilogy(1:step:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('|f(x^{(k)})-f^*|');
grid on;
axis tight

exportgraphics(gca,'../../Data/l1min_Subgradient_History.png','Resolution',300) 
