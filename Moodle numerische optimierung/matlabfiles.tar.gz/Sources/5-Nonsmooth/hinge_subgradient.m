% Subgradient function for hinge loss
close all; clear

d=5;   % no of features
s=100; % no of samples

% Example data
X = randn(s, d);        % s samples, d features
y = sign(randn(s, 1));  % Binary labels (+1 or -1)


% Main script
lambda = 1;             % Radius of the constraint set
max_iters = 100;        % Number of iterations
w0 = randn(d, 1);       % Initialize weights randomly
tolerance = 1e-4;

% Function handles for subgradient and projection
f         = @(w) hinge(w, X, y);
f_subgrad = @(w) hinge_subgrad(w, X, y);
proj = @(w) proj_onto_ball(w, lambda);


% Define a step size rule (e.g., diminishing step size)
step_size_rule = @(k) 1 / sqrt(k);
%step_size_rule = @(k) 2 / (k+1);


% Run the Projected Subgradient Method
[w_opt, f_val, allw, k_max] = projected_subgradient_method(f, f_subgrad, ...
    proj, w0, ...
    max_iters, step_size_rule,tolerance,0);


fprintf('Optimal solution: x = ['); 
for i=1:d-1
    fprintf('%.4f, ',w_opt(i));
end
fprintf('%.4f]\n',w_opt(d));
fprintf('Optimal function value: f(x) = %.4f\n', f_val);
fprintf('Iterations: %i\n', k_max);


% Plot the function value over iterations
max_i=min(k_max+1,max_iters+1);
step=1;
offset=5;
% Plot the function value over iterations
for i=1:d
    xx(i,:)=allw(i,offset:step:max_i);
end

figure;
for i=1:size(xx,2)
    allf(i) = abs(f(xx(:,i)));
end

semilogy(offset:step:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('|f(x^{(k)})|');
grid on;
axis tight

exportgraphics(gca,'../../Data/Hinge_Subgradient_History.png','Resolution',300) 




function fct = hinge(w, X, y)
    [fct,~] = hinge_loss(w, X, y);
end

function subgrad = hinge_subgrad(w, X, y)
    [~, subgrad] = hinge_loss(w, X, y);
end

% Projection onto the Euclidean ball of radius lambda
function w_proj = proj_onto_ball(w, lambda)
    w_proj = project_onto_ball(w, lambda);  % Reuse the projection function
end

function [loss, subgrad] = hinge_loss(w, X, y)
    % Inputs:
    % w - weight vector (n x 1)
    % X - data matrix (m x n)
    % y - label vector (m x 1), values +1 or -1
    
    [m, n] = size(X);
    loss = 0;
    subgrad = zeros(n, 1);

    for i = 1:m
        margin = y(i) * (w' * X(i, :)');
        if margin < 1
            loss = loss + (1 - margin);
            subgrad = subgrad - y(i) * X(i, :)';
        end
    end
end


function w_proj = project_onto_ball(w, lambda)
    % Projection of w onto the ball with radius lambda
    norm_w = norm(w, 2);
    if norm_w > lambda
        w_proj = (lambda / norm_w) * w;
    else
        w_proj = w;
    end
end