close all; clear


x_min = -2; x_max = 6;
y_min = -4;  y_max = 4;

% Wolfe's function
f = @(x,y) wolfe(x, y);

x = linspace(x_min,x_max); y = linspace(y_min,y_max);
[xx,yy] = meshgrid(x,y); ff = f(xx,yy);
levels = 0:10:120;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure, contour(x,y,ff,levels,LW,1.2), colorbar
axis([x_min x_max y_min y_max]), axis square, hold on
exportgraphics(gca,'../../Data/Wolfe_contour.png','Resolution',300) 


figure(2), mesh(x,y,ff);
view(50,30);
axis tight;
exportgraphics(gca,'../../Data/Wolfe_mesh.png','Resolution',300) 

function f = wolfe(x, y)
    % Initialize the output arrays to handle vectorized operations
    f = zeros(size(x));
 
    % Case 1: x >= |y|
    idx1 = x >= abs(y);
    f(idx1) = 5 * sqrt(9 * x(idx1).^2 + 16 * y(idx1).^2);
 
    % Case 2: 0 < x < |y|
    idx2 = (0 < x) & (x < abs(y));
    f(idx2) = 9 * x(idx2) + 16 * abs(y(idx2));

    % Case 3: x <= 0
    idx3 = x <= 0;
    f(idx3) = 9 * x(idx3) + 16 * abs(y(idx3)) - x(idx3).^9;
end

function [f, df_dx, df_dy] = wolfe_derivatives(x, y)
    % Initialize the output arrays to handle vectorized operations
    f = zeros(size(x));
    df_dx = zeros(size(x));
    df_dy = zeros(size(x));

    % Case 1: x >= |y|
    idx1 = x >= abs(y);
    f(idx1) = 5 * sqrt(9 * x(idx1).^2 + 16 * y(idx1).^2);
    df_dx(idx1) = 45 * x(idx1) ./ sqrt(9 * x(idx1).^2 + 16 * y(idx1).^2);
    df_dy(idx1) = 80 * y(idx1) ./ sqrt(9 * x(idx1).^2 + 16 * y(idx1).^2);

    % Case 2: 0 < x < |y|
    idx2 = (0 < x) & (x < abs(y));
    f(idx2) = 9 * x(idx2) + 16 * abs(y(idx2));
    df_dx(idx2) = 9;
    df_dy(idx2) = 16 * sign(y(idx2));

    % Case 3: x <= 0
    idx3 = x <= 0;
    f(idx3) = 9 * x(idx3) + 16 * abs(y(idx3)) - x(idx3).^9;
    df_dx(idx3) = 9 - 9 * x(idx3).^8;
    df_dy(idx3) = 16 * sign(y(idx3));
end




