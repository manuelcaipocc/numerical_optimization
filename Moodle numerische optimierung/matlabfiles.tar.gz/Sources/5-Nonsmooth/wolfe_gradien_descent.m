%-- gradient descent optimization method applied to the Wolfe function
%-- for varius initial values
%-- fminunc is gradient descent
%-- here: Quasi-Newton

clear; close all;
options = optimoptions('fminunc','Algorithm','trust-region',...
    'SpecifyObjectiveGradient',true);

% Wolfe's function
fun = @wolfe_derivatives;


x0=[[1 0.3]; [1 -0.3]; [1 0.5]; [1 -0.5];...
    [1 0.7]; [1 -0.7]; [1 1]];

m=size(x0,1);

fileID = fopen('../../Data/Wolfe_GradDescent.txt','w+');

for i=1:m
    fprintf('-------------------------------------------------------\n');
    fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(i,1),x0(i,2));
    [Xopt,BestF,ExitFlag,Output] = fminunc(fun,x0(i,:),options);
    fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
    fprintf('f(x^*) = (%12.8f), ',BestF);
    fprintf('no. of its: %i\n',Output.iterations);
    fprintf('-------------------------------------------------------\n');
    fprintf(fileID,'(%4.2f,%4.2f) & (%12.8f,%12.8f) & %12.8f & %i \\\\ \\hline\n',...
        x0(i,1),x0(i,2), Xopt(1),Xopt(2),BestF,Output.iterations);
end
fclose(fileID);



 

function [f, g] = wolfe_derivatives(x)
    if x(1) >= abs(x(2))
        f = 5 * sqrt(9 * x(1).^2 + 16 * x(2).^2);
        g = [45 * x(1)./ sqrt(9 * x(1).^2 + 16 * x(2).^2);
             80 * x(2)./ sqrt(9 * x(1).^2 + 16 * x(2).^2)];
    elseif  (0 < x(1)) & (x(1) < abs(x(2)))
        f = 9 * x(1) + 16 * abs(x(2));
        g = [9; 16 * sign(x(2))];
    else
        f = 9 * x(1) + 16 * abs(x(2)) - x(1).^9;
        g = [9 - 9 * x(1).^8; 16 * sign(x(2))];
    end
end