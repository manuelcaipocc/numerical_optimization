% Example usage
% Define problem parameters
A = [2, 0; 0, 2];  % Quadratic term
a = [-4; -6];      % Linear term
B = [1, 1];        % Equality constraint matrix
b = [1];           % Equality constraint vector
x0 = [0; 0];       % Initial guess for primal variables
lambda0 = [0];     % Initial guess for dual variables
tol = 1e-6;        % Convergence tolerance
max_iters = 100;  % Maximum number of iterations

% Run the Primal-Dual Active Set Method with Semi-Smooth Newton
[x_sol, lambda_sol, iter] = primal_dual_active_set_ssn(A, a, B, b, x0, lambda0, tol, max_iters);

% Display results
fprintf('Optimal value of primal variables:\n');
disp(x_sol);
fprintf('Optimal value of dual variables:\n');
disp(lambda_sol);
fprintf('Number of iterations: %d\n', iter);
