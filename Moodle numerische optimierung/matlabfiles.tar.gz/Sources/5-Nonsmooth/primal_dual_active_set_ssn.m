function [x, lambda, iter] = primal_dual_active_set_ssn(A, a, B, b, x0, lambda0, tol, max_iters)
    % Primal-Dual Active Set Method with Semi-Smooth Newton Method
    %
    % Minimize: (1/2) x' A x + a' x
    % Subject to: B x = b
    %
    % Inputs:
    % - A: Symmetric positive definite matrix in the quadratic term
    % - a: Linear term in the objective function
    % - B: Matrix for equality constraints
    % - b: Vector for equality constraints
    % - x0: Initial guess for the primal variables
    % - lambda0: Initial guess for the dual variables (Lagrange multipliers)
    % - tol: Convergence tolerance
    % - max_iters: Maximum number of iterations
    %
    % Outputs:
    % - x: Optimal primal variables
    % - lambda: Optimal dual variables
    % - iter: Number of iterations performed

    % Initialize variables
    x = x0;
    lambda = lambda0;
    m = size(B, 1);  % Number of equality constraints
    n = length(x0);  % Number of variables
    iter = 0;

    % Parameters for Semi-Smooth Newton Method
    ssn_tol = 1e-6; % Tolerance for SSN method
    max_ssn_iters = 100; % Maximum number of SSN iterations

    while iter < max_iters
        % Formulate the KKT system
        KKT_matrix = [A, B'; B, zeros(m, m)];
        rhs = [-a; b];

        % Define function handle for semi-smooth Newton method
        F = @(x_lambda) kkt_residual(KKT_matrix, rhs, x_lambda, n);
        J = @(x_lambda) kkt_jacobian(KKT_matrix, n);
        
        % Solve KKT system using Semi-Smooth Newton Method
        [x_new_lambda, ~] = semismooth_newton_method(F, J, [x; lambda], ssn_tol, max_ssn_iters);
        x_new = x_new_lambda(1:n);
        lambda_new = x_new_lambda(n+1:end);

        % Compute primal and dual residuals
        primal_residual = norm(B * x_new - b);
        dual_residual = norm(A * x_new + a - B' * lambda_new);

        % Update variables
        x = x_new;
        lambda = lambda_new;

        % Check convergence
        if primal_residual < tol && dual_residual < tol
            break;
        end

        % Update iteration count
        iter = iter + 1;
    end

    % Display results
    fprintf('Optimal value of primal variables:\n');
    disp(x);
    fprintf('Optimal value of dual variables:\n');
    disp(lambda);
    fprintf('Number of iterations: %d\n', iter);
end

function r = kkt_residual(KKT_matrix, rhs, x_lambda, n)
    % Compute the residual for the KKT system
    % Residual = KKT_matrix * [x; lambda] - rhs
    r = KKT_matrix * x_lambda - rhs;
end

function J = kkt_jacobian(KKT_matrix, n)
    % Compute the Jacobian of the KKT residual
    % For the linear system, the Jacobian is just the KKT_matrix
    J = KKT_matrix;
end
