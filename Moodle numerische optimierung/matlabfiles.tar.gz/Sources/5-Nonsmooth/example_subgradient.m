% Subgradient method for minimizing f(x_1, x_2) = 1/2 * x_1^2 + 2 * |x_2|
close all; clear

%-- function handles for f and subgradient
f = @(x) 1/2 * x(1).^2 + 2 * abs(x(2));
subgrad_f = @(x) compute_subgradient(x);  

%-- function handle for step size
step_size = @(k) step_size_rule(k);

% Parameters
max_iter  = 5000; % Maximum number of iterations
tolerance = 1e-3; % Tolerance for stopping criterion
x0 = [1.0, 1.0];  % Starting point 

% Run the subgradient method
[x_opt, f_opt, allx] = subgradient_method(f, subgrad_f, x0, ...
                                    max_iter, step_size, tolerance,1);

% Output the final result
fprintf('Optimal point: x = [%f, %f]\n', x_opt(1), x_opt(2));
fprintf('Final function value: f(x) = %f\n', f(x_opt));

max_i=100;
% Plot the function value over iterations
xx=allx(1:max_i,1);
yy=allx(1:max_i,2);
figure;
for i=1:max_i
    allf(i) = f([xx(i),yy(i)]);
end
semilogy(1:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('f(x)');
grid on;

exportgraphics(gca,'../../Data/Example_Subgradient_History.png','Resolution',300) 



%% Subgradient computation function
function g = compute_subgradient(x)
    grad_x1 = x(1);  % Gradient with respect to x_1
    if x(2) > 0
        grad_x2 = 2;   % Subgradient when x_2 > 0
    elseif x(2) < 0
        grad_x2 = -2;  % Subgradient when x_2 < 0
    else
        grad_x2 = 2 * sign(randn);  % Random subgradient when x_2 = 0
    end
    g = [grad_x1; grad_x2];
end




%% Stepsize rule
function alpha = step_size_rule(k)
    alpha = 4./(k+1);
end