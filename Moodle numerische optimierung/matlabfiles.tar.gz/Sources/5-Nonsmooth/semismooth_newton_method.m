function [allx, f_vals, iter] = semismooth_newton_method(F, J, x0, tol, max_iters)
    % Semismooth Newton method for solving nonsmooth equations
    %
    % Inputs:
    % - F: Handle to the nonsmooth function, F(x) (returns a vector)
    % - J: Handle to the generalized Jacobian, J(x) (returns a matrix)
    % - x0: Initial guess
    % - tol: Tolerance for convergence
    % - max_iters: Maximum number of iterations
    %
    % Outputs:
    % - x: Solution vector
    % - f_vals: History of the norm of F(x) at each iteration
    % - iter: Number of iterations performed
    
    % Initialize variables
    x = x0;
    allx=[x];
    f_vals = zeros(max_iters, 1);
    
    for iter = 1:max_iters
        % Evaluate the function value and Jacobian at the current iterate
        Fx = F(x);
        Jx = J(x);
        
        % Check convergence
        f_vals(iter) = norm(Fx, inf);
        if f_vals(iter) < tol
            break;
        end
        
        % Solve the linear system J(x) * delta_x = -F(x)
        delta_x = -Jx \ Fx;
        
        % Update the solution
        x = x + delta_x;
        allx = [allx, x];

        % (Optional) Display iteration details
        fprintf('Iter %d: ||F(x)||_inf = %.4e\n', iter, f_vals(iter));
    end
    
    % Truncate the f_vals array if convergence was reached early
    f_vals = f_vals(1:iter);
end

