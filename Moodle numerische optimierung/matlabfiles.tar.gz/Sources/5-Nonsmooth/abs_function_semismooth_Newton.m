close all; clear
% Define the nonsmooth function F(x) = |x|
F = @(x) abs(x);

% Define the generalized Jacobian J(x)
J = @(x) diag(sign(x) + (x == 0)); % Sign function handles nonsmoothness

% Initial guess
x0 = [2; -1; 0.5];

% Tolerance and maximum iterations
tol = 1e-6;
max_iters = 50;

% Run the Semismooth Newton Method
[x_vals, f_vals, iter] = semismooth_newton_method(F, J, x0, tol, max_iters);


% Display the results
fprintf('Solution found at x = [%.4f, %.4f, %.4f]\n', ...
    x_vals(1,end), x_vals(2,end), x_vals(3,end));
fprintf('Norm of F(x) at solution: %.4e\n', f_vals(end));
fprintf('Number of iterations: %d\n', iter);

% Plot the convergence
figure;
plot(f_vals', 'LineWidth', 2);
xlabel('Iteration');
ylabel('||F(x)||_\infty');
title('Convergence of Semismooth Newton Method');
grid on;