close all; clear;


%------------------------------------------------------------
% component functions
f1 = @(x) (x-2).^2;
f2 = @(x) x.^3;

% component subgradients
subgradient_f1 = @(x) 2*(x-2);  % Subgradient of f1(x)
subgradient_f2 = @(x) 3*x.^2;   % Subgradient of f2(x)

x_min = 0.6;
x_max = 1.2;
x0 = 1.2;              % Initial guess
%------------------------------------------------------------

% function handle for f(x) = max(f1(x), f2(x)) and subgradient
f = @(x) max(f1(x),f2(x));  
subgrad_f = @(x) compute_subgradient(x,f1(x),f2(x),...
                                     subgradient_f1(x),subgradient_f2(x));  

step_size = @(k) step_size_rule(k);

% Initial guess and parameters
max_iter = 10000;     % Maximum number of iterations
tolerance = 1e-4;    % Tolerance for convergence

% Run the subgradient method
[x_opt, f_opt, allx, max_k] = subgradient_method(f, subgrad_f, x0, ...
                                    max_iter, step_size, tolerance,0);

% Display the results
fprintf('Optimized value: x = %.4f, f(x) = %.4f\n', x_opt, f_opt);


xx=linspace(x_min,x_max,100);
figure
hold on;
plot(allx,f(allx),'r--*');
plot(xx,f(xx),'b-','LineWidth',2);
axis([x_min x_max 1 max(f(x_min),f(x_max))]);
hold off;
exportgraphics(gca,'../../Data/Max_Subgradient.png','Resolution',300) 


% Plot the function value over iterations
max_i=min(1000,max_k);
step=9;
xx=allx(1:step:max_i);
allf=abs(f(xx)-1);
figure;
semilogy(1:step:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('f(x)');
grid on;

exportgraphics(gca,'../../Data/Max_Subgradient_History.png','Resolution',300) 





%% Subgradient computation function
function g = compute_subgradient(x,f1,f2,Df1,Df2)
    % Function to compute the subgradient of f(x) = max(f1(x), f2(x))

    % Determine the active subgradient
    if f1 > f2
        g = Df1;
    elseif f1 < f2
        g = Df2;
    else
        g = 0.5 * Df1 + 0.5 * Df2;
    end
end

%% Stepsize rule
function alpha = step_size_rule(k)
    alpha = 0.01 / sqrt(k);
    % alpha = 4/(k+1);
end