%-- subgradient method applied to the Wolfe function
clear; close all;

% Wolfe's function
f = @(x) wolfe(x(1),x(2));
subgrad_f = @(x) wolfe_subgradient(x);  
step_size = @(k) step_size_rule(k);


x0=[5;4];

% Initial guess and parameters
max_iter = 10000;     % Maximum number of iterations
tolerance = 1e-4;    % Tolerance for convergence

% Run the subgradient method
[x_opt, f_opt, allx, k_max] = subgradient_method(f, subgrad_f, x0, ...
                                    max_iter, step_size, tolerance,0);

% Display the results
fprintf('Optimized value: x=(%.4f,%.4f), f(x)=%.4f, ||g(x)||=%.4f, k=%i\n\n', ...
    x_opt(1), x_opt(2), f_opt, norm(wolfe_subgradient(x_opt)), k_max);


f_exact=f([-1,0]);
max_i=min(k_max+1,10000);
step=49;
% Plot the function value over iterations
xx=allx(1,1:step:max_i);
yy=allx(2,1:step:max_i);
figure;
for i=1:length(xx)
    allf(i) = abs(f([xx(i),yy(i)])-f_exact);
end
semilogy(1:step:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('|f(x^{(k)})-f^*|');
grid on;

exportgraphics(gca,'../../Data/Wolfe_Subgradient_History.png','Resolution',300) 


%% Stepsize rule
function alpha = step_size_rule(k)
    %alpha = 4./(k+1);
    %alpha = 3./(k+1);
    %alpha = 2./(k+1);
    alpha = 1./(k+1);
end

 
function f = wolfe(x, y)
    % Initialize the output arrays to handle vectorized operations
    f = zeros(size(x));
 
    % Case 1: x >= |y|
    idx1 = x >= abs(y);
    f(idx1) = 5 * sqrt(9 * x(idx1).^2 + 16 * y(idx1).^2);
 
    % Case 2: 0 < x < |y|
    idx2 = (0 < x) & (x < abs(y));
    f(idx2) = 9 * x(idx2) + 16 * abs(y(idx2));

    % Case 3: x <= 0
    idx3 = x <= 0;
    f(idx3) = 9 * x(idx3) + 16 * abs(y(idx3)) - x(idx3).^9;
end


function g = wolfe_subgradient(x)
    if x(1) >= abs(x(2))
        g = [45 * x(1)./ sqrt(9 * x(1).^2 + 16 * x(2).^2);
             80 * x(2)./ sqrt(9 * x(1).^2 + 16 * x(2).^2)];
    elseif  (0 < x(1)) & (x(1) < abs(x(2)))
        g = [9; 16 * sign(x(2))];
    else
        g = [9 - 9 * x(1).^8; 16 * sign(x(2))];
    end
end