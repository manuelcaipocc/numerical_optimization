% Example usage: Minimize a simple convex function
% Define the objective function f(x) = x^2
f = @(x) x.^2;
grad_f = @(x) 2*x;

% Initial guess for x
x0 = 5;

% Parameters
tol = 1e-6;
max_iters = 100;

% Run the Cutting Plane Method
[x_sol, f_vals, iter] = cutting_plane_method(f, grad_f, x0, tol, max_iters);

% Display results
fprintf('Optimal value of f(x): %.4e\n', f_vals(end));
fprintf('Number of iterations: %d\n', iter);

% Plot function value over iterations
figure;
plot(1:iter, f_vals, 'b-o', 'LineWidth', 2);
xlabel('Iteration');
ylabel('f(x)');
title('Cutting Plane Method: Function Value Over Iterations');
grid on;
