% Subgradient function for hinge loss
close all; clear

d=5;   % no of features
s=100; % no of samples

% Example data
X = randn(s, d);        % s samples, d features
y = sign(randn(s, 1));  % Binary labels (+1 or -1)
% regularization parameters
tau = 2; %-- smooth part
mu = 1;    %-- hinge part

% Main script
lambda = 1;             % Radius of the constraint set
max_iters = 20;         % Number of iterations
w0 = randn(d, 1);       % Initialize weights randomly
tolerance = 1e-4;

% Function handles for subgradient and projection
f         = @(w) hinge(w, X, y, tau, mu);
f_subgrad = @(w) hinge_subgrad(w, X, y, tau, mu);
f_hessian = @(w) hinge_hessian(w, X, y, tau, mu);
proj = @(w) proj_onto_ball(w, lambda);


% Define a step size rule (e.g., diminishing step size)
step_size_rule = @(k) 1 / sqrt(k);
%step_size_rule = @(k) 2 / (k+1);


% Run the Semismooth Newton Method
[w_opt, f_vals, k_max] = semismooth_newton_method(f_subgrad, f_hessian,...
                            w0, tolerance, max_iters);


fprintf('Optimal solution: x = ['); 
for i=1:d-1
    fprintf('%.4f, ',w_opt(i,end));
end
fprintf('%.4f]\n',w_opt(d,end));
fprintf('Optimal function value: f(x) = %.4f\n', f_vals(end));
fprintf('Iterations: %i\n', k_max);


% Plot the function value over iterations
max_i=min(k_max+1,max_iters+1);
step=1;
offset=1;
% Plot the function value over iterations
for i=1:d
    xx(i,:)=w_opt(i,offset:step:max_i);
end

figure;
for i=1:size(xx,2)
    allf(i) = abs(f(xx(:,i)));
end

semilogy(offset:step:max_i, allf, 'LineWidth', 2);
xlabel('Iteration');
ylabel('|f(x^{(k)})|');
grid on;
axis tight

exportgraphics(gca,'../../Data/HingeRegularized_SemismoothNewton_History.png','Resolution',300) 




function fct = hinge(w, X, y, tau, mu)
    [fct,~,~] = hinge_loss(w, X, y, tau, mu);
end

function subgrad = hinge_subgrad(w, X, y, tau, mu)
    [~,subgrad,~] = hinge_loss(w, X, y, tau, mu);
end

function hessian = hinge_hessian(w, X, y, tau, mu)
    [~,~,hessian] = hinge_loss(w, X, y, tau, mu);
end


% Projection onto the Euclidean ball of radius lambda
function w_proj = proj_onto_ball(w, lambda)
    w_proj = project_onto_ball(w, lambda);  % Reuse the projection function
end


function [fval, grad, hess] = hinge_loss(w, X, y, tau, mu)
    % Hinge Loss function, its gradient, and generalized Hessian
    %
    % Inputs:
    % w  - weight vector (d x 1)
    % X  - data matrix (n x d) 
    % y  - label vector (n x 1) with elements in {-1, 1}
    % tau, mu  - regularization parameters
    %
    % Outputs:
    % fval - function value (scalar)
    % grad - gradient vector (d x 1)
    % hess - generalized Hessian matrix (d x d)

    % Get dimensions
    [s, d] = size(X);

    % Precompute useful quantities
    Xw = X * w;             % (s x 1) - dot products between X and w
    margin = 1 - y .* Xw;   % (s x 1) - hinge margin (y_i * (X_i^T * w))

    % Hinge loss indicator (whether 1 - y * (X_i^T * w) > 0)
    active_set = (margin > 0);  % Indicator for max(0, margin)

    % Function value (hinge loss + regularization term)
    hinge_loss = sum(max(0, margin));  % sum of hinge losses
    fval = tau * 0.5 * (w' * w) + mu * hinge_loss;

    % Gradient calculation
    grad = tau * w;  % Start with gradient of the regularization term (w)

    if nargout > 1  % Compute gradient only if required
        % Add gradient from the hinge loss term
        grad_hinge = - mu * X' * (active_set .* y);  % sum over active set
        grad = grad + grad_hinge;
    end

    % Generalized Hessian calculation
    if nargout > 2  % Compute Hessian only if required
        % Hessian of the quadratic regularization term (Identity matrix)
        hess = tau*eye(d);

        % Add contributions from the hinge loss active set
        if any(active_set)
            hess_hinge = mu * (X(active_set, :)' * X(active_set, :));
            hess = hess + hess_hinge;
        end
    end
end



function w_proj = project_onto_ball(w, lambda)
    % Projection of w onto the ball with radius lambda
    norm_w = norm(w, 2);
    if norm_w > lambda
        w_proj = (lambda / norm_w) * w;
    else
        w_proj = w;
    end
end