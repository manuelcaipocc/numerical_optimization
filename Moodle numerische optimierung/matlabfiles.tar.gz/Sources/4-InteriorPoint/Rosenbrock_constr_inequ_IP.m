%-- interior point method algorithm applied to the Rosenbrock func.
%-- with visualization of the iteration and
%-- detailed information on the iteration ('Display')

clear; close all;
%-- Rosenbrock function for contour plot
Rosenbrock = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;

x0 = [-1.9,2];
A = [2,3];
b = 1;
Aeq = [];
beq = [];
lb = [];
ub = [];

opts = optimoptions('fmincon','PlotFcn',@lsqplot,'Display','iter',...
    'Algorithm','interior-point');
fun = @(x) Rosenbrock(x(1),x(2));
[x,fval,eflag,output] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,@nlcon,opts)

exportgraphics(gca,'../../Data/Rosenbrock_inequ_IP.png','Resolution',300) 

function [c,ceq] = nlcon(x)
    ceq = [];
    c = x(1)^2 + x(2)^2 - 1.5;
end

function stop = lsqplot(x,~,state)
    persistent hist
    stop = false;

    switch state
        case 'init'
            hist = x;
            fun = @(x,y)log(1 + (10*(y - x.^2).^2 + (1 - x).^2)); 
                %--- log for cleaner contours
            fcontour(fun,[-2 2 -2 2],'LevelList',[1:5])
            hold on
            axis equal
            th = 0:pi/50:2*pi;
            xunit = sqrt(1.5) * cos(th);
            yunit = sqrt(1.5) * sin(th);
            h = plot(xunit, yunit,'k-','LineWidth',1.5);
            xx=linspace(-15,3,100);
            bd = @(x) (1/3*(1-2*x));
            plot(xx,bd(xx),'k-','LineWidth',1.5);
            xlim([-2,2])
            ylim([-2,2])
        case 'iter'
            hist = [hist;x];
            plot(x(1),x(2),"kx") %--- Plot iterative points
            plot(hist(:,1),hist(:,2),'--k')
        case 'done'
            text(hist(1,1),hist(1,2),' Start point')
            text(hist(end,1),hist(end,2),' Solution')
            hold off
    end
end
 
