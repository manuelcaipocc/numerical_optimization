% coefficients for objective function
f = -[4; 3]; % minus sign for maximization

%- inequality constraints
B = [2, 3; 3, 2];
b = [7; 6];

%- variables are non-negative - lower bounds
lb = [0; 0];
ub = [];

options = optimoptions('linprog','Algorithm','interior-point',...
    'Display','iter');
[x, fval] = linprog(f, B, b, [], [], lb, ub, options);

%- output
fprintf('Optimal amount of productin for D1 (x1): %.2f\n', x(1));
fprintf('Optimal amount of productin for D2 (x2): %.2f\n', x(2));
fprintf('Maximal profit: %.2f\n', -fval); 
    %- nagative value due to minimization
