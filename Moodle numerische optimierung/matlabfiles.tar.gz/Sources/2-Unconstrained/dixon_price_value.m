function f = dixon_prize_value(varargin) 
    numInputs = nargin;
    f = zeros(1, numInputs);
    
    % Loop over each input vector
    for k = 1:numInputs
        x = varargin{k};
        x = x(:);
        d = length(x);
        
        term1 = (x(1) - 1)^2;
        sum_terms = 0;
        
        for i = 2:d
            sum_terms = sum_terms + i * (2*x(i)^2 - x(i-1))^2;
        end        
        f(k) = term1 + sum_terms;
    end
end
