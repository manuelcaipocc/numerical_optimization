f = @(x,y) (x.^2+y-11).^2+(x+y.^2-7).^2;

x = linspace(-5,5); y = linspace(-5,5);
[xx,yy] = meshgrid(x,y); ff = f(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure, contour(x,y,ff,levels,LW,1.2), colorbar
axis([-5 5 -5 5]), axis square, hold on
exportgraphics(gca,'../../Data/Himmelblau_contour.png','Resolution',300) 


figure(2), mesh(x,y,ff);
exportgraphics(gca,'../../Data/Himmelblau_mesh.png','Resolution',300) 
