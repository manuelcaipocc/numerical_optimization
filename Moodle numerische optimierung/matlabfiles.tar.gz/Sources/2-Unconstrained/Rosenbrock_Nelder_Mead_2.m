%-- Nelder-Mead optimization method applied to the Rosenbrock function
%-- with visualization of the iteration and
%-- detailed information on the iteration ('Display')

clear; close all;
%-- Rosenbrock function for contour plot
Rosenbrock = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;


x = linspace(-1.5,1.5); y = linspace(-1.5,3);
[xx,yy] = meshgrid(x,y); ff = Rosenbrock(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([-1.5 1.5 -1.5 3]), axis square, hold on

%-- Rosenbrock function for Nelder-Mead
f = @(x) Rosenbrock(x(1),x(2));

%-- options for output display and iterations 
options=optimset('OutputFcn',@outfun,'Display','iter','MaxIter',200)
%-- initial value
x0=[-1 -1];
%-- fminserach is Nelder-Mead
fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(1),x0(2));
[Xopt,BestF,ExitFlag,Output] = fminsearch(f,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f),\t',BestF);
fprintf('no. of its: %o\n\n',Output.iterations);

exportgraphics(gca,'../../Data/Rosenbrock_Nelder_Mead_Iter.png','Resolution',300) 


%-- displays the iterations
function stop = outfun( x,optimValues,state )
 stop=false;
 hold on;
 plot(x(1),x(2),'*','MarkerSize',12);
 drawnow
end
