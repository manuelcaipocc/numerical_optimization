%-- Hooke-Jeeves optimization method applied to the Bazaraa_Shetty function
%-- for varius initial values
clear; close all;


%-- Bazaraa_Shetty function
f = @(x) (x(1)-2).^4+(x(1)-2*x(2)).^2;

x0=[[1.5,1.3];[2,1.3];[2.4,1.3];[1.5,1.1];[2,1.1];[2.4,1.1];...
    [1.5,0.8];[2,0.8];[2.4,0.8];...
    [2,1]];

m=size(x0,1);

for i=1:m
    fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(i,1),x0(i,2));
    [Xopt,BestF,Iters] = hookejeeves(x0(i,:), [.1 .1], [1e-5 1e-5], 1e-7, 1000, f);
    fprintf('Optimal point x^*: (%12.8f, %12.8f)\n',Xopt(1),Xopt(2));
    fprintf('\t f(x^*) = (%12.8f), ',BestF);
    fprintf('no. of its: %o\n',Iters);
    fprintf('-------------------------------------------------------\n');
end

