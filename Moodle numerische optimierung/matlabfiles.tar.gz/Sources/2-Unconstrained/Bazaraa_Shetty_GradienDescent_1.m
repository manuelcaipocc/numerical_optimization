%-- gradient descent optimization method applied to the Bazaraa_Shetty function
%-- for varius initial values
%-- fminunc is gradient descent
%-- here: Quasi-Newton

clear; close all;
options = optimoptions('fminunc','Algorithm','quasi-newton');

%-- Bazaraa_Shetty function
f = @(x) (x(1)-2).^4+(x(1)-2*x(2)).^2;

x0=[[-1 -1]; [0 0]; [0.5 0.5]; [0.75 0.75];...
    [0.95 0.95]; [0.99 0.99]; [1 1]];

m=size(x0,1);

fileID = fopen('../../Data/Bazaraa_Shetty_GradDescent_1.txt','w+');

for i=1:m
    fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(i,1),x0(i,2));
    [Xopt,BestF,ExitFlag,Output] = fminunc(f,x0(i,:),options);
    fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
    fprintf('f(x^*) = (%12.8f), ',BestF);
    fprintf('no. of its: %i\n',Output.iterations);
    fprintf('-------------------------------------------------------\n');
    fprintf(fileID,'(%4.2f,%4.2f) & (%12.8f,%12.8f) & %12.8f & %i \\\\ \\hline\n',...
        x0(i,1),x0(i,2), Xopt(1),Xopt(2),BestF,Output.iterations);
end
fclose(fileID);



 


