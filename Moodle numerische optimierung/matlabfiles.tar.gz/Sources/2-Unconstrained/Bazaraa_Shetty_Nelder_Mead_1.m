%-- Nelder-Mead optimization method applied to the Bazaraa_Shetty function
%-- for varius initial values
clear; close all;
options=optimset('MaxIter',1500)

%-- Bazaraa_Shetty function
f = @(x) (x(1)-2).^4+(x(1)-2*x(2)).^2;

x0=[[-1,-1];[4,4];[-2,4];[-3,-2];...
    [3.5,-2];[3.5,-1.8];...
    [3.1,2.05];...
    [-2.8,3.1];...
    [-3.7,-3.2]];

m=size(x0,1);

for i=1:m
    fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(i,1),x0(i,2));
    [Xopt,BestF,ExitFlag,Output] = fminsearch(f,x0,options);
    fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
    fprintf('f(x^*) = (%12.8f), ',BestF);
    fprintf('no. of its: %o\n',Output.iterations);
    fprintf('-------------------------------------------------------\n');
end





