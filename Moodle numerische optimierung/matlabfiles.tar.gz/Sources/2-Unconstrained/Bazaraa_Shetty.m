f = @(x,y) (x-2).^4+(x-2*y).^2;

x = linspace(1.6,2.6); y = linspace(0.8,1.3);
[xx,yy] = meshgrid(x,y); ff = f(xx,yy);
levels = 0:0.01:1;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure, contour(x,y,ff,levels,LW,1.2), colorbar
axis([1.6 2.6 0.8 1.3]), axis square, hold on
exportgraphics(gca,'../../Data/Bazaraa_Shetty_contour.png','Resolution',300) 


figure(2), mesh(x,y,ff);
exportgraphics(gca,'../../Data/Bazaraa_Shetty_mesh.png','Resolution',300) 
