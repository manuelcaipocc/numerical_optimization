%-- Nelder-Mead optimization method applied to the Rosenbrock function
%-- for varius initial values
clear; close all;
options=optimset('MaxIter',200)

%-- Rosenbrock function
f = @(x) (1-x(1)).^2 + 100*(x(2)-x(1).^2).^2;

x0=[[-1 -1]; [0 0]; [0.5 0.5]; [0.75 0.75];...
    [0.95 0.95]; [0.99 0.99]; [1 1]];

m=size(x0,1);

for i=1:m
    fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(i,1),x0(i,2));
    [Xopt,BestF,ExitFlag,Output] = fminsearch(f,x0,options);
    fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
    fprintf('f(x^*) = (%12.8f), ',BestF);
    fprintf('no. of its: %o\n',Output.iterations);
    fprintf('-------------------------------------------------------\n');
end





