% Newton's method using Wolfe's stepsize rule.
% It terminates when the norm of the gradient is below 10^(-6).
close all; clear

x=[-1 -1]';
fprintf('Initial point x0: (%12.8f, %12.8f),\n',x(1),x(2));

% Rosenbrock function and derivative
Rosenbrock = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;
f  = @(x) Rosenbrock(x(1),x(2));
JF = @(x) [-400*(x(2)-x(1)^2)*x(1)-2*(1-x(1));
            200*(x(2)-x(1)^2)];
HF = @(x)  [1200*x(1)^2-400*x(2)+2, -400*x(1);...
                         -400*x(1), 200];  

c1  = 1e-4;
c2  = 0.9;
rho = 0.5;
k=1;
nf=1;		% nf = # function eval.	
allx = x;

fileID = fopen('../../Data/Rosenbrock_Newton_Wolfe.txt','w+');

while(1)
    [grd_f] = JF(x); nf=nf+1;
    norm_gf = norm(grd_f,2);
    if norm_gf < 1e-6  % Stopping criteria
        break 
    else
        d_k = -HF(x)\grd_f; %%- Newton
        [alpha,h_alpha,f_value,nfun]=find_upper_alpha(JF,x,d_k);
        nf = nf+nfun;
        wolfe = c2*d_k'*grd_f;
        [alpha, nfun] = line_search(f,JF,wolfe,alpha,h_alpha,x,d_k,grd_f,c1);
        trace_x(:,k) = x;
        nf = nf+nfun;
        x = x + alpha*d_k;
        allx=[allx,x];
        alpha = 1;
        obj=f(x);
        fprintf('%5.0f %5.0f %12.5e \n',k,nf,obj);
        fprintf(fileID,'%5.0f & %5.0f & %12.5e \\\\ \\hline\n',k,nf,obj); 
        k = k +1; 
    end
end

fclose(fileID);

fprintf('Optimal point x^*: (%12.8f, %12.8f)\n',x(1),x(2));
fprintf('f(x^*) = %12.8f\n',f(x));
fprintf('#f = %i, ',nf);
fprintf('no. of its: %i\n\n',k);

  
x = linspace(-1.5,1.5); y = linspace(-1.5,3);
[xx,yy] = meshgrid(x,y); ff = Rosenbrock(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([-1.5 1.5 -1.5 3]), axis square, hold on
plot(allx(1,:),allx(2,:),'k+-','LineWidth',1.0);
hold off
exportgraphics(gca,'../../Data/Rosenbrock_Newton_Wolfe.png','Resolution',300) 


function [alpha,h_alpha,Fp_value,nfun]=find_upper_alpha(JF,x,d_k)
    alpha = 1;
    ii = 1; nfun=0;
    while(1)
        mx = x + alpha*d_k;
        [grd_f] = JF(mx); nfun=nfun+1;
        if d_k'*grd_f < 0
            h_alpha(ii)  = alpha;
            Fp_value(ii) = d_k'*grd_f;
            alpha = 1.25*alpha; % 1.25 is an arbitrarily chosen constant
        else
            h_alpha(ii)  = alpha;
            Fp_value(ii) = d_k'*grd_f;
            break
        end
    ii = ii + 1; 
    end
end

function  [alpha,nfun] = line_search(f,JF,WolfE,alpha,h_alpha,x,d_k,grd_f,c1)
    rho = 0.5; nfun=0;
    % there is no interval for alpha, try Armijo’s condition
    if length(h_alpha) == 1
        while(1)
            new_x = x + alpha*d_k;
            [f_nx] = f(new_x); 
            [f_ox] = f(x);    nfun=nfun+2;
            if f_nx > f_ox + c1*alpha*d_k'*grd_f
                alpha = rho*alpha;
            else
                break 
            end
        end
    else
    % length(h_alpha) > 1, there exists an interval for alpha
        L_alpha = h_alpha(length(h_alpha)-1); U_alpha = alpha;
        while(1) % Use Dichotomous section
            t_alpha = 0.5*(L_alpha+U_alpha);
            mx = x + t_alpha*d_k;
            [grd_f] = JF(mx); nfun=nfun+1;
            if d_k'*grd_f > 0
                U_alpha = t_alpha;
            else
                if d_k'*grd_f > WolfE % Wolfe condition is satisfied
                    break
                else
                    L_alpha = t_alpha;
                end
            end
        end
    alpha = t_alpha;
    end
end
 
  