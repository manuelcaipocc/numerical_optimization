f = @(x,y) (1-x).^2 + 100*(y-x.^2).^2;

x = linspace(-1.5,1.5); y = linspace(-1,3);
[xx,yy] = meshgrid(x,y); ff = f(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure, contour(x,y,ff,levels,LW,1.2), colorbar
axis([-1.5 1.5 -1 3]), axis square, hold on
exportgraphics(gca,'../../Data/Rosenbrock_contour.png','Resolution',300) 


figure(2), mesh(x,y,ff);
exportgraphics(gca,'../../Data/Rosenbrock_mesh.png','Resolution',300) 
