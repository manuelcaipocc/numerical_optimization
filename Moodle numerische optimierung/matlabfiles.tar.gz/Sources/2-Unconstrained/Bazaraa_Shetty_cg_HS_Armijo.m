% nonlinear cg-HS method using the Armijo step size control
% It terminates when the norm of the gradient is below 10^(-6).
close all; clear

x=[-1 -1]';
fprintf('Initial point x0: (%12.8f, %12.8f),\n',x(1),x(2));

% Bazaraa_Shetty function and derivative
Bazaraa_Shetty = @(x,y) (x-2).^4+(x-2*y).^2;
f  = @(x) Bazaraa_Shetty(x(1),x(2));
JF = @(x) [4*(x(1)-2).^3+2*(x(1)-2*x(2));
           4*(2*x(2)-x(1))];
        
% Armijo stepsize rule parameters
sigma = .1;
obj=f(x);
p=JF(x);
d=-p;
k=0;        % k = # iterations
nf=1;		% nf = # function eval.	
allx = x;

fileID = fopen('../../Data/Bazaraa_Shetty_cg_HS.txt','w+');
    
% Begin method
  while  norm(p) > 1e-6    
    alpha = 1;
    newobj = f(x + alpha*d); nf = nf+1;
    while (newobj-obj)/alpha > sigma*p'*d  %-- Armijo rule
      alpha = alpha*0.5;
      newobj = f(x + alpha*d); nf = nf+1;
    end
    if (mod(k,10)==1) 
        fprintf('%5.0f %5.0f %12.5e \n',k,nf,newobj); 
        fprintf(fileID,'%5.0f & %5.0f & %12.5e \\\\ \\hline\n',k,nf,newobj); 
    end
    x = x + alpha*d;
    allx = [allx,x];
    pnew = JF(x);
    beta = (pnew'*(pnew-p))/((pnew-p)'*d);
    d    = -pnew + beta*d;
    p    = pnew;
    obj  = newobj;
    k    = k + 1;
  end
  
fclose(fileID);
  
fprintf('Optimal point x^*: (%12.8f, %12.8f)\n',x(1),x(2));
fprintf('f(x^*) = %12.8f\n',obj);
fprintf('#f = %i, ',nf);
fprintf('no. of its: %i\n\n',k);

x = linspace(1.6,2.6); y = linspace(0.8,1.3);
[xx,yy] = meshgrid(x,y); ff = Bazaraa_Shetty(xx,yy);
levels = 0:0.01:1;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([1.6 2.6 0.8 1.3]), axis square, hold on
plot(allx(1,:),allx(2,:),'k+-','LineWidth',1.0);
hold off
exportgraphics(gca,'../../Data/Bazaraa_Shetty_cg_HS.png','Resolution',300) 
