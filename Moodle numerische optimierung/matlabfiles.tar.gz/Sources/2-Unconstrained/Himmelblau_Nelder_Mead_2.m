%-- Nelder-Mead optimization method applied to the Himmelblau function
%-- with visualization of the iteration and
%-- detailed information on the iteration ('Display')

clear; close all;
% Himmelblau function and derivative
Himmelblau = @(x,y) (x.^2+y-11).^2+(x+y.^2-7).^2;

x = linspace(-5,5); y = linspace(-5,5);
[xx,yy] = meshgrid(x,y); ff = Himmelblau(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([-5 5 -5 5]), axis square, hold on

%-- Himmelblau function for Nelder-Mead
f = @(x) Himmelblau(x(1),x(2));

%-- options for output display and iterations 
options=optimset('OutputFcn',@outfun,'Display','iter','MaxIter',200)
%-- initial value
x0=[-1 -1];
%-- fminserach is Nelder-Mead
fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(1),x0(2));
[Xopt,BestF,ExitFlag,Output] = fminsearch(f,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f),\t',BestF);
fprintf('no. of its: %o\n\n',Output.iterations);

exportgraphics(gca,'../../Data/Himmelblau_Nelder_Mead_Iter.png','Resolution',300) 


%-- displays the iterations
function stop = outfun( x,optimValues,state )
 stop=false;
 hold on;
 plot(x(1),x(2),'*','MarkerSize',12);
 drawnow
end
