%-- gradient descent method algorithm applied to the Bazaraa_Shetty func.
%-- with visualization of the iteration and
%-- detailed information on the iteration ('Display')
%-- fminunc is gradient descent
%-- compare Quasi-Newton with Newton (inlc. derivatives)

clear; close all;
%-- Bazaraa_Shetty function for contour plot
Bazaraa_Shetty = @(x,y) (x-2).^4+(x-2*y).^2;

%-- Bazaraa_Shetty function
x = linspace(1.6,2.6); y = linspace(0.8,1.3);
[xx,yy] = meshgrid(x,y); ff = Bazaraa_Shetty(xx,yy);
levels = 0:0.01:1;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([1.6 2.6 0.8 1.3]), axis square, hold on
exportgraphics(gca,'../../Data/Bazaraa_Shetty_Function.png','Resolution',300) 

x0=[1.5 1]';

%-- first check Quasi-Newton without derivatieves
options = optimoptions('fminunc','Algorithm','quasi-newton');
f = @(x) Bazaraa_Shetty(x(1),x(2));
fprintf('Quasi-Newton\n');
[Xopt,BestF,ExitFlag,Output] = fminunc(f,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f), ',BestF);
fprintf('no. of its: %o\n',Output.iterations);

fprintf('-------------------------------------------------------\n')


%-- now Quasi-Newton with derivative
%-- amounts to set the algorithm to Trust-Region
options = optimoptions('fminunc','Algorithm','trust-region',...
    'SpecifyObjectiveGradient',true,'OutputFcn',@outfun);

fun = @Bazaraa_Shettywithgrad;
fprintf('Quasi-Newton with Jacobian\n');
[Xopt,BestF,ExitFlag,Output] = fminunc(fun,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f), ',BestF);
fprintf('no. of its: %o\n',Output.iterations);

fprintf('-------------------------------------------------------\n')


%-- now Newton with Hessian 
options = optimoptions('fminunc','Algorithm','trust-region',...
    'SpecifyObjectiveGradient',true,'HessianFcn','objective');


fun = @rosenboth;
fprintf('Newton with Hessian\n');
[Xopt,BestF,ExitFlag,Output] = fminunc(fun,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f), ',BestF);
fprintf('no. of its: %o\n',Output.iterations);

fprintf('-------------------------------------------------------\n')

exportgraphics(gca,'../../Data/Bazaraa_Shetty_Steepest_Descent_3.png','Resolution',300) 


function [f,g] = Bazaraa_Shettywithgrad(x)
    %- Bazaraa_Shetty function and gradient
    f = (x(1)-2).^4+(x(1)-2*x(2)).^2;
    if nargout > 1 % gradient required
        g = [4*(x(1)-2).^3+2*(x(1)-2*x(2));
              4*(2*x(2)-x(1))];
    end
end

function [f, g, H] = rosenboth(x)
    % Calculate objective f
    f = (x(1)-2).^4+(x(1)-2*x(2)).^2;

    if nargout > 1 % gradient required
        g = [4*(x(1)-2).^3+2*(x(1)-2*x(2));
             4*(2*x(2)-x(1))];

        if nargout > 2 % Hessian required
            H = [12*(x(1)-2).^2+2, 8;...
                    8, -4];  
        end

    end
end

function stop = outfun( x,optimValues,state )
 stop=false;
 hold on;
 plot(x(1),x(2),'*','MarkerSize',12);
 drawnow
end
 
