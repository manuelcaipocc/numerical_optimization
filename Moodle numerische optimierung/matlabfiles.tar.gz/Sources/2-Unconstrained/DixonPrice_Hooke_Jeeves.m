%-- Hooke-Jeeves optimization method applied to the Dixon-Price function
%-- for varius initial values
clear; 

d=2;

%-- Dixon-Price function
f = @(x) dixon_price_value(x);

x0=[[-1,-1];[2,2];[-1,2];[-2,-1];...
    [0,0];[1,0];[0,1];[1,0.7]];

m=size(x0,1);

for i=1:m
    fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(i,1),x0(i,2));
    [Xopt,BestF,Iters] = hookejeeves(x0(i,:), [.1 .1], [1e-5 1e-5], 1e-7, 1000, f);
    fprintf('Optimal point x^*: (%12.8f, %12.8f)\n',Xopt(1),Xopt(2));
    fprintf('\t f(x^*) = (%12.8f), ',BestF);
    fprintf('no. of its: %o\n',Iters);
    fprintf('-------------------------------------------------------\n');
end

