function [x,BestF,Iters] = hookejeeves(x0, StepSize, MinStepSize, tol, MaxIter, myFx)
% multivariate optimization using the Hooke-Jeeves search method.
%
% Input:
% - x0 - array of initial guesses
% - StepSize - array of search step sizes
% - MinStepSize - array of minimum step sizes
% - tol - tolerance for difference in successive function values
% - MaxIter - maximum number of iterations
% - myFx - objective function
%
% Output:
% - x - array of optimized variables
% - BestF - function value at optimum
% - Iters - number of iterations
%

n=size(x0);
Xnew = x0;
BestF = myFx(Xnew); 
LastBestF = 100 * BestF + 100;

bGoOn = true;
Iters = 0;

while bGoOn

  Iters = Iters + 1;
  if Iters > MaxIter
    break;
  end
  x = Xnew;

  %-- exploration step
  for i=1:n
    bMoved(i) = 0;
    bGoOn2 = true;
    while bGoOn2
      xx = Xnew(i);
      Xnew(i) = xx + StepSize(i);
      F = myFx(Xnew);
      if F < BestF
        BestF = F;
        bMoved(i) = 1;
      else
        Xnew(i) = xx - StepSize(i);
        F = myFx(Xnew);
        if F < BestF
          BestF = F;
          bMoved(i) = 1;
        else
          Xnew(i) = xx;
          bGoOn2 = false;
        end
      end
    end
  end

  bMadeAnyMove = sum(bMoved);

  %-- progression
  if bMadeAnyMove > 0
    DeltaX = Xnew - x;
    lambda = 0.5;
    lambda = linsearch(x, lambda, DeltaX, myFx);
    Xnew = x + lambda * DeltaX;
  end

  BestF = myFx(Xnew);

  %-- reduce the step size for the dimensions that had no moves
  for i=1:n
    if bMoved(i) == 0
      StepSize(i) = StepSize(i) / 2;
    end
  end

  if abs(BestF - LastBestF) < tol
    break
  end

  LastBest = BestF;
  bStop = true;
  for i=1:n
    if StepSize(i) >= MinStepSize(i)
      bStop = false;
    end
  end

  bGoOn = ~bStop;

end


function lambda = linsearch(x, lambda, D, myFx)
  MaxIt = 100;
  Toler = 0.000001;

  iter = 0;
  bGoOn = true;
  while bGoOn
    iter = iter + 1;
    if iter > MaxIt
      lambda = 0;
      break
    end

    h = 0.01 * (1 + abs(lambda));
    f0 = myFx(x+lambda*D);
    fp = myFx(x+(lambda+h)*D);
    fm = myFx(x+(lambda-h)* D);
    deriv1 = (fp - fm) / 2 / h;
    deriv2 = (fp - 2 * f0 + fm) / h ^ 2;
    diff = deriv1 / deriv2;
    lambda = lambda - diff;
    if abs(diff) < Toler
      bGoOn = false;
    end
  end
