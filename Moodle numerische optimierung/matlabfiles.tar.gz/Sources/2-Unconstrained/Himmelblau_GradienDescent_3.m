%-- gradient descent method algorithm applied to the Himmelblau func.
%-- with visualization of the iteration and
%-- detailed information on the iteration ('Display')
%-- fminunc is gradient descent
%-- compare Quasi-Newton with Newton (inlc. derivatives)

clear; close all;
%-- Himmelblau function for contour plot
Himmelblau = @(x,y) (x.^2+y-11).^2+(x+y.^2-7).^2;

%-- Himmelblau function
x = linspace(-5,5); y = linspace(-5,5);
[xx,yy] = meshgrid(x,y); ff = Himmelblau(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([-5 5 -5 5]), axis square, hold on
exportgraphics(gca,'../../Data/Rosenbrock_Function.png','Resolution',300) 

x0 = [0,0];

%-- first check Quasi-Newton without derivatieves
options = optimoptions('fminunc','Algorithm','quasi-newton');
f = @(x) Himmelblau(x(1),x(2));
fprintf('Quasi-Newton\n');
[Xopt,BestF,ExitFlag,Output] = fminunc(f,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f), ',BestF);
fprintf('no. of its: %o\n',Output.iterations);

fprintf('-------------------------------------------------------\n')


%-- now Quasi-Newton with derivative
%-- amounts to set the algorithm to Trust-Region
options = optimoptions('fminunc','Algorithm','trust-region',...
    'SpecifyObjectiveGradient',true,'OutputFcn',@outfun);

fun = @himmelblauwithgrad;
fprintf('Quasi-Newton with Jacobian\n');
[Xopt,BestF,ExitFlag,Output] = fminunc(fun,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f), ',BestF);
fprintf('no. of its: %o\n',Output.iterations);

fprintf('-------------------------------------------------------\n')


%-- now Newton with Hessian 
options = optimoptions('fminunc','Algorithm','trust-region',...
    'SpecifyObjectiveGradient',true,'HessianFcn','objective');


fun = @himmelboth;
fprintf('Newton with Hessian\n');
[Xopt,BestF,ExitFlag,Output] = fminunc(fun,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f), ',BestF);
fprintf('no. of its: %o\n',Output.iterations);

fprintf('-------------------------------------------------------\n')

exportgraphics(gca,'../../Data/Himmelblau_Steepest_Descent_3.png','Resolution',300) 


function [f,g] = himmelblauwithgrad(x)
    %- Himmelblau function and gradient
    f = (x(1).^2+x(2)-11).^2+(x(1)+x(2).^2-7).^2;
    if nargout > 1 % gradient required
        g = [x(1).*(4*x(1).^2+4*x(2)-42)+2*(x(2).^2-7);
             x(2).*(4*x(2).^2+4*x(1)-26)+2*(x(1).^2-11)];
    end
end

function [f, g, H] = himmelboth(x)
    % Calculate objective f
    f = (x(1).^2+x(2)-11).^2+(x(1)+x(2).^2-7).^2;

    if nargout > 1 % gradient required
        g = [x(1).*(4*x(1).^2+4*x(2)-42)+2*(x(2).^2-7);
             x(2).*(4*x(2).^2+4*x(1)-26)+2*(x(1).^2-11)];

        if nargout > 2 % Hessian required
            H = [12*x(1).^2+4*x(2)-42, 4*x(1)+4*x(2);...
                        4*x(1)+4*x(2), 12*x(2).^2+4*x(1)-26];  
        end

    end
end

function stop = outfun( x,optimValues,state )
 stop=false;
 hold on;
 plot(x(1),x(2),'*','MarkerSize',12);
 drawnow
end
 
