%-- Nelder-Mead optimization method applied to the Bazaraa_Shetty function
%-- with visualization of the iteration and
%-- detailed information on the iteration ('Display')

clear; close all;
%-- Bazaraa_Shetty function for contour plot
Bazaraa_Shetty = @(x,y) (x-2).^4+(x-2*y).^2;


x = linspace(1.6,2.6); y = linspace(0.8,1.3);
[xx,yy] = meshgrid(x,y); ff = Bazaraa_Shetty(xx,yy);
levels = 0:0.01:1;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([1.6 2.6 0.8 1.3]), axis square, hold on

%-- Bazaraa_Shetty function for Nelder-Mead
f = @(x) Bazaraa_Shetty(x(1),x(2));

%-- options for output display and iterations 
options=optimset('OutputFcn',@outfun,'Display','iter','MaxIter',200)
%-- initial value
x0=[-1 -1];
%-- fminserach is Nelder-Mead
fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(1),x0(2));
[Xopt,BestF,ExitFlag,Output] = fminsearch(f,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f),\t',BestF);
fprintf('no. of its: %o\n\n',Output.iterations);

exportgraphics(gca,'../../Data/Bazaraa_Shetty_Nelder_Mead_Iter.png','Resolution',300) 


%-- displays the iterations
function stop = outfun( x,optimValues,state )
 stop=false;
 hold on;
 plot(x(1),x(2),'*','MarkerSize',12);
 drawnow
end
