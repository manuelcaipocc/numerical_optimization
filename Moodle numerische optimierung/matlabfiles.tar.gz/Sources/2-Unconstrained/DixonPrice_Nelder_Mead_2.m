%-- Nelder-Mead optimization method applied to the Dixon-Price function
%-- with visualization of the iteration and
%-- detailed information on the iteration ('Display')

clear; close all;
%--Dixon-Price function for contour plot
Dixon_Price = @(x,y) dixon_price_value([x,y]);

x_min = -2; x_max = 2;
y_min = -2; y_max = 2;


[xx,yy] = meshgrid(x_min:0.1:x_max, y_min:0.1:y_max);
ff = zeros(size(xx));
for i = 1:size(xx, 1)
    for j = 1:size(yy, 2)
        ff(i, j) = dixon_price_value([xx(i, j); yy(i, j)]);
    end
end
levels = 0:2:200;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(xx,yy,ff,levels,LW,1.2), colorbar
axis([x_min x_max y_min y_max]), axis square, hold on

%-- Dixon_Price function for Nelder-Mead
f = @(x) Dixon_Price(x(1),x(2));

%-- options for output display and iterations 
options=optimset('OutputFcn',@outfun,'Display','iter','MaxIter',200)
%-- initial value
x0=[-1 -1];
%-- fminserach is Nelder-Mead
fprintf('Initial point x0: (%12.8f, %12.8f),\n',x0(1),x0(2));
[Xopt,BestF,ExitFlag,Output] = fminsearch(f,x0,options);
fprintf('Optimal point x^*: (%12.8f, %12.8f), ',Xopt(1),Xopt(2));
fprintf('f(x^*) = (%12.8f),\t',BestF);
fprintf('no. of its: %o\n\n',Output.iterations);

exportgraphics(gca,'../../Data/Dixon_Price_Nelder_Mead_Iter.png','Resolution',300) 


%-- displays the iterations
function stop = outfun( x,optimValues,state )
 stop=false;
 hold on;
 plot(x(1),x(2),'*','MarkerSize',12);
 drawnow
end
