% nonlinear cg-PR method using the Armijo step size control
% It terminates when the norm of the gradient is below 10^(-6).
close all; clear

x=[-1 -1]';
fprintf('Initial point x0: (%12.8f, %12.8f),\n',x(1),x(2));

% Himmelblau function and derivative
Himmelblau = @(x,y) (x.^2+y-11).^2+(x+y.^2-7).^2;

f  = @(x) Himmelblau(x(1),x(2));
JF = @(x) [x(1).*(4*x(1).^2+4*x(2)-42)+2*(x(2).^2-7);
           x(2).*(4*x(2).^2+4*x(1)-26)+2*(x(1).^2-11)];
        
% Armijo stepsize rule parameters
sigma = .1;
obj=f(x);
p=JF(x);
d=-p;
k=0;        % k = # iterations
nf=1;		% nf = # function eval.	
allx = x;

fileID = fopen('../../Data/Himmelblau_cg_PR.txt','w+');
    
% Begin method
  while  norm(p) > 1e-6    
    alpha = 1;
    newobj = f(x + alpha*d); nf = nf+1;
    while (newobj-obj)/alpha > sigma*p'*d  %-- Armijo rule
      alpha = alpha*0.5;
      newobj = f(x + alpha*d); nf = nf+1;
    end
    if (mod(k,10)==1) 
        fprintf('%5.0f %5.0f %12.5e \n',k,nf,newobj); 
        fprintf(fileID,'%5.0f & %5.0f & %12.5e \\\\ \\hline\n',k,nf,newobj); 
    end
    x = x + alpha*d;
    allx = [allx,x];
    pnew = JF(x);
    beta = (pnew'*(pnew-p))/(p'*p);
    d    = -pnew + beta*d;
    p    = pnew;
    obj  = newobj;
    k    = k + 1;
  end
  
fclose(fileID);
  
fprintf('Optimal point x^*: (%12.8f, %12.8f)\n',x(1),x(2));
fprintf('f(x^*) = %12.8f\n',obj);
fprintf('#f = %i, ',nf);
fprintf('no. of its: %i\n\n',k);

x = linspace(-5,5); y = linspace(-5,5);
[xx,yy] = meshgrid(x,y); ff = Himmelblau(xx,yy);
levels = 10:10:300;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure(1), contour(x,y,ff,levels,LW,1.2), colorbar
axis([-5 5 -5 5]), axis square, hold on
plot(allx(1,:),allx(2,:),'k+-','LineWidth',1.0);
hold off
exportgraphics(gca,'../../Data/Himmelblau_cg_PR.png','Resolution',300) 
