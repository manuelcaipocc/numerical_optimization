close all; clear

x_min = -2; x_max = 2;
y_min = -2; y_max = 2;

[xx,yy] = meshgrid(x_min:0.1:x_max, y_min:0.1:y_max);
ff = zeros(size(xx));
for i = 1:size(xx, 1)
    for j = 1:size(yy, 2)
        ff(i, j) = dixon_price_value([xx(i, j); yy(i, j)]);
    end
end

levels = 0:2:200;
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
figure, contour(xx,yy,ff,levels,LW,1.2), colorbar
axis([x_min x_max y_min y_max]), axis square, hold on
exportgraphics(gca,'../../Data/DixonPrice_contour.png','Resolution',300) 


figure(2), mesh(xx,yy,ff);
exportgraphics(gca,'../../Data/DixonPrice_mesh.png','Resolution',300) 


