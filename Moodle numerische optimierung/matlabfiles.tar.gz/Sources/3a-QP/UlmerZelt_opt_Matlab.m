close all; clear

height = zeros(33);
height(6:7,6:7) = 0.3;
height(26:27,26:27) = 0.3;
height(6:7,26:27) = 0.3;
height(26:27,6:7) = 0.3;
height(16:17,16:17) = 0.5;

%-- insert for extra entrance --
height(2:8,14:18) = 0.2;
%-------------------------------

colormap(gray);
surfl(height)
axis tight
view([-20,30]);
% title('Tent Poles and Region to Cover')
exportgraphics(gca,'../../Data/UlmerZeltPoles.png','Resolution',300) 

x = optimvar('x',size(height));

boundary = false(size(height));
boundary([1,33],:) = true;
boundary(:,[1,33]) = true;
x.LowerBound(boundary) = 0;
x.UpperBound(boundary) = 0;

L = size(height,1);
peStretch = optimexpr(L,L); % This initializes peStretch to zeros(L,L)
interior = 2:(L-1);
peStretch(interior,interior) = (-1*(x(interior - 1,interior) + x(interior + 1,interior) ...
    + x(interior,interior - 1) + x(interior,interior + 1)) + 4*x(interior,interior))...
    .*x(interior, interior);

peHeight = x/30000;

tentproblem = optimproblem('Objective',sum(sum(peStretch + peHeight)));

htcons = x >= height;
tentproblem.Constraints.htcons = htcons;

sol = solve(tentproblem);

figure(2)
surfl(sol.x);
axis tight;
view([-20,30]);
exportgraphics(gca,'../../Data/UlmerZelt_Solution.png','Resolution',300) 
