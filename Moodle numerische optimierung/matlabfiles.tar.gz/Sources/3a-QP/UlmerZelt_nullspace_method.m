close all; clear
dim=64;
[A,a,B,b]  = UlmerZelt(dim);
[x,lambda] = nullspace_method(A,a,B,b);

%-- pad x by zeros to enforce zero boundary conditions
u = zeros(dim+2,dim+2);
for i=1:dim
    u(i+1,2:dim+1) = x((i-1)*dim+1:i*dim);
end

%-- export solution
surf(u); axis tight; view([-20,30]);
exportgraphics(gca,'../../Data/UlmerZelt-NullSpace.png','Resolution',300) 
