H = [1 -1; -1 2]; 
f = [-2; -6];
A = [1 1; -1 2; 2 1];
a = [2; 2; 3];

[x,fval,exitflag,output,lambda] = quadprog(H,f,A,a);

x,fval,exitflag