function [A,a,B,b] = UlmerZelt(n)
%-- data for the tent optiomization problem
%-- uses function blktridiag.m

dim=n*n;

e = ones(n,1);
Amd  = spdiags([-e 4*e -e], -1:1, n, n);
Asub = spdiags([-e], 0, n, n);
A = 2*blktridiag(Amd,Asub,Asub,n);
%-- factor 2 due to form f(x)=1/2 x^TAx + a^Tx
%--                      s.t. Bx=b


i1=floor(n/4);
i2=floor(n/2);
i3=floor(3*n/4);

%-- fixing 4 positions for the tent
B=zeros(20,dim);
B(1,index(i2,i2,n))=1;
B(2,index(i2,i2+1,n))=1;
B(3,index(i2+1,i2,n))=1;
B(4,index(i2+1,i2+1,n))=1;

B(5,index(i1,i1,n))=1;
B(6,index(i1,i1+1,n))=1;
B(7,index(i1+1,i1,n))=1;
B(8,index(i1+1,i1+1,n))=1;

B(9,index(i1,i3,n))=1;
B(10,index(i1,i3+1,n))=1;
B(11,index(i1+1,i3,n))=1;
B(12,index(i1+1,i3+1,n))=1;

B(13,index(i3,i1,n))=1;
B(14,index(i3,i1+1,n))=1;
B(15,index(i3+1,i1,n))=1;
B(16,index(i3+1,i1+1,n))=1;

B(17,index(i3,i3,n))=1;
B(18,index(i3,i3+1,n))=1;
B(19,index(i3+1,i3,n))=1;
B(20,index(i3+1,i3+1,n))=1;

b=zeros(20,1);
b(1:4)=0.5;
b(5:20)=0.3;


rho=1/3000;
a=rho*ones(dim,1);
end

%-- to compute 2d indices
function k=index(i,j,n)
    k=(j-1)*n+i;
end