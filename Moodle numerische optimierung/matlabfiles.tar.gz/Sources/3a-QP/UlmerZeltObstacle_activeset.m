close all; clear
%-- computes optimization problem for the tent
%-- using quadratic programming

n=64;
tol=1e-6;
[A,a,B,b,C,c,x0]=UlmerZeltObstacle(n);
[x, lambda, mu, fval, exitflag, its] = activeset(A,a,B,b,C,c,x0,tol);

fprintf('Active set terminated after %i iterations.\n',its);
fprintf('Function value: %12.8f\n',fval);
fprintf('Optimality residual: %12.8f\n',norm(A*x-a));
fprintf('Inequality residual: %12.8f\n',norm(C*x-c));
fprintf('Equality residual:   %12.8f\n',norm(B*x-b));

u = zeros(n+2,n+2);
u0 = zeros(n+2,n+2);
for i=1:n
    u(i+1,2:n+1) = x((i-1)*n+1:i*n);
    u0(i+1,2:n+1) = x0((i-1)*n+1:i*n);
end

figure(1)
surf(u);axis tight;view([-20,30]);
exportgraphics(gca,'../../Data/UlmerZeltObstacle_ActiveSet.png','Resolution',300) 

figure(2)
surf(u0);axis tight;view([-20,30]);
exportgraphics(gca,'../../Data/UlmerZeltObstacle_Initial.png','Resolution',300) 
