function [A,a,B,b,C,c,x0] = UlmerZeltObstacle(n)
%-- data for the tent optiomization problem
%-- uses function blktridiag.m
%-- x0 is a feasible point

    dim=n*n;

    e  = ones(n,1);
    x0 = zeros(dim,1);
    
    Amd  = spdiags([-e 4*e -e], -1:1, n, n);
    Asub = spdiags([-e], 0, n, n);
    A = 2*blktridiag(Amd,Asub,Asub,n);
    %-- factor 2 due to form f(x)=1/2 x^TAx + b^Tx
    %--                      s.t. Bx=g


    %-- equality constraints
    i1=floor(n/4);
    i2=floor(n/2);
    i3=floor(3*n/4);

    %-- fixing 4 positions for the tent
    B=zeros(20,dim);
    B(1,index(i2,i2,n))=1;
    B(2,index(i2,i2+1,n))=1;
    B(3,index(i2+1,i2,n))=1;
    B(4,index(i2+1,i2+1,n))=1;

    B(5,index(i1,i1,n))=1;
    B(6,index(i1,i1+1,n))=1;
    B(7,index(i1+1,i1,n))=1;
    B(8,index(i1+1,i1+1,n))=1;

    B(9,index(i1,i3,n))=1;
    B(10,index(i1,i3+1,n))=1;
    B(11,index(i1+1,i3,n))=1;
    B(12,index(i1+1,i3+1,n))=1;

    B(13,index(i3,i1,n))=1;
    B(14,index(i3,i1+1,n))=1;
    B(15,index(i3+1,i1,n))=1;
    B(16,index(i3+1,i1+1,n))=1;

    B(17,index(i3,i3,n))=1;
    B(18,index(i3,i3+1,n))=1;
    B(19,index(i3+1,i3,n))=1;
    B(20,index(i3+1,i3+1,n))=1;

    b=zeros(5,1);
    b(1:4)=0.5;
    b(5:20)=0.3;

    x0(index(i2,i2,n))      =b(1);
    x0(index(i2,i2+1,n))    =b(2);
    x0(index(i2+1,i2,n))    =b(3);
    x0(index(i2+1,i2+1,n))  =b(4);

    x0(index(i1,i1,n))      =b(5);
    x0(index(i1,i1+1,n))    =b(6);
    x0(index(i1+1,i1,n))    =b(7);
    x0(index(i1+1,i1+1,n))  =b(8);

    x0(index(i1,i3,n))      =b(9);
    x0(index(i1,i3+1,n))    =b(10);
    x0(index(i1+1,i3,n))    =b(11);
    x0(index(i1+1,i3+1,n))  =b(12);

    x0(index(i3,i1,n))      =b(13);
    x0(index(i3,i1+1,n))    =b(14);
    x0(index(i3+1,i1,n))    =b(15);
    x0(index(i3+1,i1+1,n))  =b(16);

    x0(index(i3,i3,n))      =b(17);
    x0(index(i3,i3+1,n))    =b(18);
    x0(index(i3+1,i3,n))    =b(19);
    x0(index(i3+1,i3+1,n))  =b(20);

    c=1/30000;
    a=c*ones(dim,1);

    %-- inequality constraints
    j1=floor(7*n/16);
    j2=floor(9*n/16);

    k1=2;
    k2=floor(n/4);

    m=(j2-j1+1)*(k2-k1+1);

    C=zeros(m,dim);
    c=(-0.2)*ones(m,1);
    ind=1;
    for i=j1:j2
        for j=k1:k2
            C(ind,index(i,j,n))=-1;
            x0(index(i,j,n))=(-1)*c(ind);
            ind=ind+1;
        end
    end    
end

%-- to compute 2d indices
function k=index(i,j,n)
    k=(j-1)*n+i;
end