clear
n=10;

%===================================================================
%-- data
x0 = ones(n,1)./n;

rho = [-6.089; -17.164; -34.054; -5.914; -24.721;...
    -14.986; -24.100; -10.708; -26.662; -22.179];

fx  = @(x) x'*(rho+log(x./(sum(x))));
Jfx = @(x) rho + log(x./(sum(x)));
Hfx = @(x) diag(1./x) - ones(n,n)./(sum(x));

B=zeros(3,10);
B(1,1)=1;
B(1,2)=2;
B(1,3)=2; B(3,3)=1;
B(2,4)=1;
B(2,5)=2;
B(1,6)=1; B(2,6)=1;
B(2,7)=1; B(3,7)=1;
B(3,8)=1;
B(3,9)=2;
B(1,10)=1; B(3,10)=1;

b=[2;1;1];

%-- inequality constraints
C=(-1)*eye(n);
c=zeros(n,1);
%===================================================================

%---------- fmincon-SQP --------------------------------------------
options = optimoptions('fmincon','Display','iter','Algorithm','sqp');
[x,fval,exitflag,output] = fmincon(fx,x0,C,c,B,b,[],[],[],options);

x
fval

%---------- fmincon-Newtn-SQP --------------------------------------
options = optimoptions('fmincon','SpecifyObjectiveGradient',true);
fx2=@funwithgrad;
[x,fval,exitflag,output] = fmincon(fx2,x0,C,c,B,b,[],[],[],options);

x
fval

%-------------------- own SQP --------------------------------------

%-- finding a feasible starting point
%------------------------------------
%--- feasible initial by hands
x0new=[8/5;1/20;1/20;7/10;1/20;1/10;1/10;13/20;1/20;1/10];

%--- non-feasible intial -> wrong solution!
% eps=rand(9,1)-0.5;
% eps=(3e-5)*eps;
% eps(10)=1-sum(eps);
% x0new=x+eps;

fprintf('Feasible x0: ||Bx0-b||=%12.8f, min(x_0)=%6.4f\n',...
    norm(B*x0new-b),min(x0new));

tol=1e-6;
c=(-1)*(1e-6)*ones(n,1);
[x,lambda,mu,its] = sqp(fx,Jfx,Hfx,B,b,C,c,x0new,tol);

x
fx(x)

function [f,g] = funwithgrad(x)
    rho = [-6.089; -17.164; -34.054; -5.914; -24.721;...
        -14.986; -24.100; -10.708; -26.662; -22.179];    
    f = x'*(rho+log(x./sum(x)));
    if nargout > 1 % gradient required
        g = rho + log(x./sum(x));
    end
end
