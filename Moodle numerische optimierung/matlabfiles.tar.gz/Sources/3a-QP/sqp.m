function [x,lambda,mu,its] = sqp(f,Jf,Hf,B,b,C,c,x0,tol)
    n  = size(B,2);
    m  = size(B,1);
    p  = size(C,1);
    x  = x0;
    its=0; 
  
    reseq=norm(B*x0-b);
    resie=max(C*x0-c>0);
            
    if (reseq>tol) || (resie==1)
       fprintf('  *** Warning: x0 in sqp is infeasible: ');
       fprintf('||Bx-b||=%12.8f; Cx-r>0; %i\n',reseq,resie);
    end
 
    fileID = fopen('../../Data/SQP_output.txt','w');

    noready = 1;
    fprintf(fileID,'$\\texttt{its}$ & $\\|d\\|$ & $f(x)$ & $\\|Jf(x)\\|$');
    fprintf(fileID,' & $\\|Bx-b\\|$ & $\\max(Cx-c)!<0$ \\\\ \\hline\n');
    fprintf(fileID,'%i & %12.8f & %12.8f & %12.8f & %12.8f & %12.8f\\\\ \\hline\n',...
           its,0,f(x),norm(Jf(x)),norm(B*x-b),max(C*x-c));

    while noready
       Ak=Hf(x);
       bk=Jf(x);
       gk=zeros(m,1);
       rk=c-C*x;
       d0=zeros(n,1);    %-- initial value for direction
       [d,lambda,mu] = activeset(Ak,bk,B,gk,C,rk,d0,1e-6);
       if norm(d)<tol
            noready=0; break
       end
       x = x+d; 
       its=its+1;
       fprintf(fileID,'%i & %12.8f & %12.8f & %12.8f & %12.8f & %12.8f\\\\ \\hline\n',...
           its,norm(d),f(x),norm(Jf(x)),norm(B*x-b),max(C*x-c));
    end
    fclose(fileID);
    return
end
