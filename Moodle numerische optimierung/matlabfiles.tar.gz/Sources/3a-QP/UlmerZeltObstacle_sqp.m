close all; clear
%-- computes optimization problem for the tent using sqp
n=64;
tol=1e-6;
[A,b,B,g,C,r,x0]=UlmerZeltObstacle(n);

fx  = @(x) 0.5*x'*A*x + b'*x;
Jfx = @(x) A*x+b;
Hfx = @(x) A;

fprintf('x0 feasible: %12.8f\n',norm(B*x0-g));
[x, lambda, mu, its] = sqp(fx,Jfx,Hfx,B,g,C,r,x0,tol);
fprintf('sqp terminated after %i iterations.\n',its);

u = zeros(n+2,n+2);
u0 = zeros(n+2,n+2);
for i=1:n
    u(i+1,2:n+1) = x((i-1)*n+1:i*n);
    u0(i+1,2:n+1) = x0((i-1)*n+1:i*n);
end

figure(1)
surf(u);axis tight;view([-20,30]);
exportgraphics(gca,'../../Data/UlmerZeltObstacle_ActiveSet.png','Resolution',300) 

figure(2)
surf(u0);axis tight;view([-20,30]);
exportgraphics(gca,'../../Data/UlmerZeltObstacle_Initial.png','Resolution',300) 
