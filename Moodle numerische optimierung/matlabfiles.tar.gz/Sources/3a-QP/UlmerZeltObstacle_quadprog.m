close all; clear
%-- computes optimization problem for the tent
%-- using quadratic programming

n=64;
[A,a,B,b,C,c]=UlmerZeltObstacle(n);

x = quadprog(A,a,C,c,B,b);

u = zeros(n+2,n+2);
for i=1:n
    u(i+1,2:n+1) = x((i-1)*n+1:i*n);
end
surf(u);
axis tight;
view([-20,30]);

exportgraphics(gca,'../../Data/UlmerZeltObstacle.png','Resolution',300) 

