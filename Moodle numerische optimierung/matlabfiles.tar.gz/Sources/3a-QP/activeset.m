function [x_opt,lambda,mu,fval,exitflag,its] = activeset(A,a,B,b,C,c,x0,tol,maxIter)
    % acitve set method for quadratic problems
    % Minimize: 0.5*x'*A*x + b'*x
    % Subject to: B * x = g, C * x <= r

    if nargin<9
        maxIter = 1000;
    end

    %-- No Inequality Constraints
    if size(C,1) == 0
        [x,lambda] = nullspace_method(A,a,B,b); mu = zeros(0,1);
        return
    end

    %-- Initialization
    x = x0;
    m           = size(B,1);
    lambda      = zeros(m, 1);
    mu          = zeros(size(C, 1), 1);  
    activeSet   = [];
    inactiveSet = 1:size(C, 1);

    for iter = 1:maxIter
        %-- solve KKT for feasible descent direction
        %-- could also be done e.g. by nullspace method
        ghelp = A*x + a;
        Bhelp = [B; C(activeSet, :)];
        bhelp = [b; c(activeSet)];

        if isempty(Bhelp)
            d = -A \ ghelp;
        else
            KKT = [A, Bhelp'; Bhelp, zeros(size(Bhelp, 1))];
            rhs = [-ghelp; zeros(size(Bhelp, 1), 1)];
            sol = KKT \ rhs;
            d = sol(1:length(x));
            lambda = sol(length(x) + 1:length(x) + m);
            if isempty(activeSet)
                mu=[];
            else
                mu(activeSet) = sol(length(x) + 1 + m:end);
            end
        end
        %---------------------------------------
        if norm(d) < tol
            if all(mu >= 0)  %--case 1
                exitflag = 1;
                break;
            else             %-- case 2: inactivation
                [~, idx] = min(mu(activeSet));
                activeSet(idx) = [];
                continue;
            end
        end

                             %-- case 3
        sigma = 1;           %-- step size determination
        for i = inactiveSet
            a_i = C(i, :);
            b_i = c(i);
            if a_i * d > 0
                sigma = min(sigma, (b_i - a_i * x) / (a_i * d));
            end
        end

        x = x + sigma * d;
        if sigma < 1
            idx = find(abs(C * x - c) < tol);
            activeSet   = unique([activeSet; idx]);
            inactiveSet = setdiff(1:size(C, 1), activeSet);
        end
    end

    x_opt = x;
    fval = 0.5 * x' * A * x + a' * x;
    its = iter;
    if iter == maxIter
        exitflag = 0;
    end
end
