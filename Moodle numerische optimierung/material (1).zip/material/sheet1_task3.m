% Gauss-Newton Method
clc; clear; close all;

% Define the parameter
lambda = -1.1;

% Define the residual function
f = @(x) [ x + 1; lambda*x.^2 + x - 1 ];

% Define the Jacobian of the residual function
J = @(x) [ 1; 2*lambda*x + 1 ];

% Function for newtons method
g = @(x) 0.5*((x+1).^2+(lambda*x.^2+x-1).^2);
nabla_g = @(x) x*(2*lambda.^2*x.^2+3*lambda*x-2*(lambda-1));
Hess_g  = @(x) 6*lambda.^2*x.^2+6*lambda*x-2*(lambda-1);

% Define the initial value and termination parameters
x0   = 10; 
maxIt = 1e3;
tol   = 1e-10;

% Apply the Gauss-Newton method
[x_GN, res, iter_GN, error_hess] = gaussNewton_ChatGPT(f, J, Hess_g, x0, maxIt, tol);
% Apply the Newton method
[x_N, iter_N] = newtonsMethod(nabla_g, Hess_g, x0, maxIt, tol);

% Plot the path taken by the Gauss-Newton method
figure(1);
subplot(2,1,1);
semilogy(1:iter_GN+1, vecnorm(x_GN,2,1), 'r-o', 'MarkerSize', 5, ...
     'LineWidth', 1.5);
hold on
semilogy(1:iter_N+1, vecnorm(x_N,2,1), 'b-x', 'MarkerSize', 5, ...
     'LineWidth', 1.5);

title("Gaus-Netwon and Newton Convergence");
xlabel('Iterations');
ylabel('Absolute Error $\Vert x_{sol}-x^{(k)} \Vert_2$',Interpreter='latex');
legend('Gaus-Newton','Newton');
grid on;
hold off
fontsize(16,"points")

subplot(2,1,2);
plot(1:iter_GN, error_hess, 'r-x', 'MarkerSize', 5, ...
     'LineWidth', 1.5);
hold on
title("Error of Hessian approximation");
xlabel('Iterations');
ylabel('Error [100%]');
legend('error of hessian GN', 'error of hessian LM');
grid on;
hold off;
fontsize(16,"points")
