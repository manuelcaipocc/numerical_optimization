function [x,iter,error_hess, mu] = LevenbergMarquardt(F, dF, hessian_g, ...
                                                      x0, muk, ...
                                                      beta0, beta1, ...
                                                      maxIt, tol)

% Initialise iterates
x     = x0;
[M,N] = size(x0);

% iteration count
k = 1;

F_xk  = F(x0);
dF_xk = dF(x0);

% set up the matrix and right hand side for LSQP
A = [dF_xk;muk^2*eye(M)];
b = [-F_xk;zeros(M,N)];

% linear least squares problem solver
s     = lscov(A,b); 
F_xks = F(x0+s);

% estimator for mu
eps_mu = (F_xk'*F_xk - F_xks'*F_xks) / ...
    (F_xk'*F_xk - (F_xk+dF_xk*s)'*(F_xk+dF_xk*s));


% Iteration
while norm(s) > tol && k < maxIt
    
    % while steps are not accepted try to double the penalty parameter
    while eps_mu <= beta0
        % double mu if step is not accepted
        muk = 2*muk;
        
        % set up the matrix and right hand side for LSQP
        A = [dF_xk;muk^2*eye(M)];
        b = [-F_xk;zeros(M,N)];

        % linear least squares problem solver
        s = lscov(A,b); 
        
        % calculate the residual at x_k+1
        F_xks = F(x(:,k)+s);
        
        % estimator for mu
        eps_mu = (F_xk'*F_xk - F_xks'*F_xks) / ...
          (F_xk'*F_xk - (F_xk+dF_xk*s)'*(F_xk+dF_xk*s)); 

        if norm(s) < tol
            break
        end
    end
    
    % if mu is too large half it
    if eps_mu >= beta1
        muk = muk/2;
    end
    
    % take a step
    x(:,k+1) = x(:,k) + s;
    
    % eval residual and derivative
    F_xk  = F(x(:,k+1));
    dF_xk = dF(x(:,k+1));
    

    % set up the matrix and right hand side for LSQP
    A = [dF_xk;muk^2*eye(M)];
    b = [-F_xk;zeros(M,N)];

    % linear least squares problem solver
    s = lscov(A,b); 

    % update residual
    F_xks = F(x(:,k)+s);
    
    % estimator for mu
    eps_mu = (F_xk'*F_xk - F_xks'*F_xks) / ...
        (F_xk'*F_xk - (F_xk+dF_xk*s)'*(F_xk+dF_xk*s));
    
    % update iteration count
    k = k + 1;
end

iter = k;

end
