function [x, iter] = newtonsMethod(F, J, x0, maxIter, tol)
    % NEWTONSMETHOD Solve a system of nonlinear equations using Newton's method.
    %
    % Inputs:
    %   F        - Handle to the function F(x) = 0 (nx1 vector of equations)
    %   J        - Handle to the Jacobian matrix J(x) (nxn matrix)
    %   x0       - Initial guess for the solution (nx1 vector)
    %   maxIter  - Maximum number of iterations (default 100)
    %   tol      - Tolerance for convergence (default 1e-6)
    %
    % Outputs:
    %   x        - Solution vector (nx1) for all iterations

    % Set defaults if not provided
    if nargin < 4, maxIter = 100; end
    if nargin < 5, tol = 1e-6; end

    % Initialize variables
    x = x0;
    
    for iter = 1:maxIter
        % Evaluate function and Jacobian at the current x
        Fx = F(x(iter));   % Function value (n x 1)
        Jx = J(x(iter));   % Jacobian matrix (n x n)

        % Solve for the Newton step: J(x) * dx = -F(x)
        dx = -Jx \ Fx;

        % Update the solution
        x(iter+1) = x(iter) + dx;

        % Check for convergence
        if norm(Fx,2) < tol
            fprintf('Newton''s method converged in %d iterations.\n', iter);
            break;
        end
    end

    % Display warning if max iterations are reached
    if iter == maxIter
        warning(['Newton''s method did not converge within the maximum' ...
            ' number of iterations.']);
    end
end
