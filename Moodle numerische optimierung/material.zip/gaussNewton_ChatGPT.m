function [x, res, iter, error_hess] = gaussNewton_ChatGPT(func, ...
                                                          jacobian, hess, ...
                                                          x0, maxIter, tol)
    % GAUSSNEWTON Solve nonlinear least squares using the Gauss-Newton method.
    %
    % Inputs:
    %   func      - Handle to the function f(x) = residuals (nx1 vector)
    %   jacobian  - Handle to the Jacobian of the function J(x) (nxm matrix)
    %   hess      - Handle to the hessian of the function g
    %   x0        - Initial guess for the parameters (mx1 vector)
    %   maxIter   - Maximum number of iterations (default 100)
    %   tol       - Tolerance for convergence (default 1e-6)
    %
    % Outputs:
    %   x         - Optimized parameter vector (mx1) for all iterations
    %   res       - Final residual norm ||f(x)||
    %   norm_JJ   - Norm of (J' * J)

    % Set defaults if not provided
    if nargin < 4, maxIter = 100; end
    if nargin < 5, tol = 1e-6; end

    % Initialize variables
    x = x0;
    for iter = 1:maxIter
        % Evaluate the function and its Jacobian at the current x
        r = func(x(iter));              % Residual vector (n x 1)
        J = jacobian(x(iter));          % Jacobian matrix (n x m)
        
        % Norm of (J' * J)
        error_hess(iter) = norm((J' * J)-hess(x(iter)),2)/norm(hess(x(iter)),2);

        % Solve the linear system: J'J dx = -J'r
        dx = -(J' * J) \ (J' * r);  % Parameter update
        
        % Update the parameter vector
        x(iter+1) = x(iter) + dx;

        % Check for convergence
        if norm(dx) < tol
            fprintf('Converged in %d iterations.\n', iter);
            break;
        end
    end

    % Compute final residual norm
    res = norm(func(x(iter)));

    % Display a message if the method did not converge
    if iter == maxIter
        warning(['Gauss-Newton did not converge within the maximum number ' ...
            'of iterations.']);
    end
end
