function [xk, niter] = gradientDescentForwardDiff(func, x0, alpha, maxIt, tol, x_sol, epsilon)
% Gradient Descent using Forward Differences to approximate the gradient
% Inputs:
%   func       - Handle to the function to minimize (e.g., cost function)
%   x0         - Initial parameter values (column vector)
%   alpha      - step size
%   num_iters  - Number of iterations
%   epsilon    - Step size for forward difference approximation (default: 1e-5)
% Outputs:
%   xk      - Optimized parameters
%   niter   - Number of iterations

if nargin < 7
    epsilon = 1e-5;  % Set default epsilon if not provided
end

xk      = x0;       % Initialize parameters
n       = size(xk,1);        % Number of parameters
niter = 0;
for iter = 1:maxIt
    % Compute cost for current xk
    cost = func(xk);
    
    % Initialize gradient vector
    gradient = zeros(n, 1);
    
    % Forward Difference Approximation for Gradient
    for j = 1:n
        xk_temp    = xk;
        xk_temp(j) = xk_temp(j) + epsilon;  % Perturb theta[j]
        cost_plus_epsilon = func(xk_temp);     % Compute f(theta + epsilon)
        
        % Forward difference gradient approximation
        gradient(j) = (cost_plus_epsilon - cost) / epsilon;
    end
    
    % Update theta
    xk = xk - alpha * gradient;

    % update counter
    niter = niter + 1;

    if norm(x_sol-xk) < tol
        return
    end

end
end
