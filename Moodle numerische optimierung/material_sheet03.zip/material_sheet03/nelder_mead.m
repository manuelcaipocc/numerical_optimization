function [x,niter] = nelder_mead(f, x0, alpha, beta, gamma, tol, maxIt)
% performs the Nelder-Mead algorithm
n = size(x0,2);
% sort the n-simplex
f_vec = zeros(1,n);
f_=0;
for i = 1:n
    f_vec(i) = f(x0(:,i));
    f_ = f_ + f_vec(i);
end
f_ = 1/n*f_;
[~,indx] = sort(f_vec,'ascend');
x = zeros(n-1,n,maxIt+1);
x(:,:,1)=x0(:,indx);
% determine x_(t) and f(x(-alpha))
c = sum(x(:,1:n-1,1),2)/(n-1);
x_ = @(t) c + t*(x(:,n,1)-c);
stop_crit = 1/(n-1)*sum((f_vec-f_).^2);
niter=1;
while stop_crit > tol && niter <= maxIt
    % nelder-mead step
    xa = x_(-alpha); fa = f(xa);
    if f(x(:,1,niter)) <= fa && fa <= f(x(:,n-1,niter))
        x(:,n,niter+1) = xa;
    elseif fa < f(x(:,1,niter))
        xab = x_(-alpha*beta); fab = f(xab);
        if fab < fa
            x(:,n,niter+1) = xab;
        else
            x(:,n,niter+1) = xa;
        end
    else % f(-alpha) >f(xn)
        if f(x(:,n-1,niter)) < fa && fa < f(x(:,n,niter))
            xag = x_(-alpha*gamma); fag = f(xag);
            if fag <= fa
                x(:,n,niter+1) = xag;
            else
                x(:,2:n,niter+1) = 0.5*(x(:,1,niter)+x(:,2:n,niter));
            end
        else % fa is the worst value
            xg = x_(gamma); fg = f(xg);
            if fg < f(x(:,n,niter))
                x(:,n,niter+1) = xg;
            else
                x(:,2:n,niter+1) = 0.5*(x(:,1,niter)+x(:,2:n,niter));
            end
        end
    end
    x(:,1:n-1,niter+1) = x(:,1:n-1,niter);
    % stopping criterium
    f_ = 0;
    for i = 1:n
        f_vec(i) = f(x(:,i,niter+1));
        f_ = f_ + f_vec(i);
    end
    f_ = 1/n*f_;
    [~,indx] = sort(f_vec,'ascend');
    x(:,1:n,niter+1) = x(:,indx,niter+1);
    stop_crit = 1/(n-1)*sum((f_vec-f_).^2);
    c = (1/(n-1)).*sum(x(:,1:n-1,niter+1),2);
    x_ = @(t) c + t*(x(:,n,niter+1)-c);
    niter=niter+1;
end

end

