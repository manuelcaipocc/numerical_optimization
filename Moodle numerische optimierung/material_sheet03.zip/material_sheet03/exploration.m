function [x] = exploration(f, x, h)
% exploration step
n = length(x);

for j=1:n
    ej = zeros(n,1);
    ej(j) = 1;
    if f(x+h(j)*ej) < f(x)
        x = x+ h(j)*ej;
    else
        if f(x-h(j)*ej) < f(x)
            x = x-h(j)*ej;
        end
    end
end

end