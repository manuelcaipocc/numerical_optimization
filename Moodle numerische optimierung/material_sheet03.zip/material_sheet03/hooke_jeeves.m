function [xk,niter] = hooke_jeeves(f, x0, h, tol, maxIt, x_sol)
% performs the Hooke-Jeeves algorithm
k       = 0;
xk      = x0;
while norm(xk - x_sol) > tol && k <= maxIt
    yk = exploration(f, xk, h);
    if yk == xk
        h = 0.5*h;
        if norm(h,inf) < tol
            warning("The step size h is below the tolerance")
            niter = k;
            return
        end
    else
        wk = 2*yk - xk;
        zk = exploration(f, wk, h);
        if f(zk) < f(yk)
            xk = zk;
        else
            xk = yk;
        end
        k=k+1;
    end
end
niter = k;
end