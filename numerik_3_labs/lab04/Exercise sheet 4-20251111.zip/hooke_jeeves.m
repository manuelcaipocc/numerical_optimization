%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUTS:
% f: map from R^n to R
% x0: starting point, (n x 1)-dimensional 
% h0: starting step sizes, (n x 1)-dimensional 
% tol: tolerance >0
%
% VARIABLES:
% x: current iterate, (n x 1)-dimensional 
% X: matrix containing all iterates, (n x (number iteration steps + 1))-dimensional
% h: current step sizes, (n x 1)-dimensional 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function[X] = hooke_jeeves(f, x0, h0, tol)

x = x0;
X = [x0];
h = h0;

% iterate until termination criterion met
while ...

    % perform exploration step
    ...

    % if expl. step does not produce progress
    ...
        
        % half step sizes and new expl. step
        ...

    % if expl. step does produce progress
    ...

        % second exploration step 
        ...

        % if second expl. step better than first expl. step
        ...

        % if not
        ...

        X = [X,x];
       
    end

end

end



% exploration step in own function
function[x] = explore(f, x, h)

n = ...

% examine along coordinate axes of all n dimensions
for ...

    % positive direction
    t_pos = ...

    % negative direction
    t_neg = ...

    % if decrease in positive direction
    ...

    % if no decrease in positive direction, but decrease in negative direction
    ...

end

end